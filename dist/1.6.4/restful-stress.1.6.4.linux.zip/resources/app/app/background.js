// //Add listener for application installation
// chrome.runtime.onInstalled.addListener(function() 
// {
// 	//Log on console installation confirm
// 	console.log("RESTful Stress installed");		
// });

// //Add listener for application launch
// chrome.app.runtime.onLaunched.addListener(function(launchData) {

// 	//*** GOOGLE CLOUD MESSAGING
// 	//https://developers.google.com/cloud-messaging/

//   	//Create popup message
// 	chrome.app.window.create("main.html", { 
// 			bounds : {
// 				left: 20,
// 				top: 50,
// 				width: 1000,
// 				height: 700
// 			}
// 		});
// });

/*** INUTILIZZATO ***/