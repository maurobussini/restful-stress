(function () {
    angular
    .module("RestfulStress")
    .controller("HistoryController",
    ['$scope', '$location', "$timeout", 'trackingService','$uibModal', "downloadService", "parseService", "integrationService",
    function ($scope, $location, $timeout, trackingService, $uibModal, downloadService, parseService, integrationService) {

        //#region Bindable elements
        var ctrl = this;
        ctrl.isBusy = false;
        ctrl.items = null;
        ctrl.fetch = fetch;
        ctrl.exportCsv = exportCsv;
        ctrl.download = download;
        ctrl.upload = upload;
        //#endregion

        //Creates history model
        function createHistoryModel(data){

            //Arguments validation
            if (!data) throw new Error("Argument 'data' is invalid");

            //Calculate time relative/absolute
            var momentTime = moment(data.start);
            var relativeTime = momentTime.fromNow();
            var absoluteTime = momentTime.format('HH:mm:ss');

            //Calculate size
            var size = !data.data
                ? 0
                : JSON.stringify(data.data).length;

            //Create model
            var model = {
                iterationNumber: data.iterationNumber,  //Iteration number
                start: absoluteTime,                    //Start time
                startRelative: relativeTime,            //Start time relative
                status: data.status,                    //Http status code
                duration: data.duration,                //Duration of invoke
                isSuccess: data.isSuccess,              //Success or fail
                isWarmup: data.isWarmup,                //Current is warmup
                data: data.data,                        //Response data or error
                size: size                              //Size in bytes
            };

            //Function to show data
            model.showData = function(){

                //Open modal dialog
                $uibModal.open({
                    templateUrl: 'app/history/body.html',
                    controller: 'BodyController as bodyCtrl',
                    backdrop: 'static',
                    resolve: {
                        historyItem: function () {
                            return model;
                        }
                    }
                });
            };

            //Returns model
            return model;
        }

        //Fetches data from service
        function fetch(){

            //Set busy indicator
            ctrl.isBusy = true;

            //Execute with delay to avoid UI freeze
            $timeout(function(){

                //Fetch data from tracked service
                trackingService.fetch().then(function(data){

                    //Clear previous data
                    ctrl.isBusy = false;
                    ctrl.items = [];

                    //Create models
                    var models = [];
                    for(var i = 0; i < data.length; i++){
                        models.push(createHistoryModel(data[i]));
                    }

                    //Push models on scope
                    ctrl.items = models;
                });

            }, 10);
        }

        //Exports CSV file with data
        function exportCsv() {

            //Extract history in CSV format
            ctrl.isBusy = true;
            integrationService.downloadHistoryCsv().then(function(csvContent){

                //Execute download of file
                ctrl.isBusy = false;
                downloadService.download(csvContent, "history.csv", "csv").then(
                    function(){
                        toastr.success("CSV file was downloaded with success");
                    },
                    function(err){
                        toastr.error("Error during download: " + err);
                    });
            });
        }

        //Download history content to local filesystem
        function download(){

            //Extract history in JSON format
            ctrl.isBusy = true;
            integrationService.downloadHistoryJson().then(function(json){

                //Execute download of file
                ctrl.isBusy = false;
                downloadService.download(json, "history.json", "json").then(
                    function(){
                        toastr.success("Current history was downloaded with success");
                    },
                    function(err){
                        toastr.error("Error during download: " + err);
                    });
            });
        }

        //Upload and restore history
        function upload(){

            //Open file from local (upload on extension)
            downloadService.upload('json').then(
                function(data){

                    //Execute import of data
                    ctrl.isBusy = true;
                    integrationService.uploadHistoryJson(data).then(
                        function(){

                            //Confirm operation
                            ctrl.isBusy = false;
                            toastr.success("History was uploaded and restored with success");

                            //Force fetch from tracking
                            fetch();
                        },
                        function(importError){

                            //Show error during import
                            ctrl.isBusy = false;
                            toastr.error(importError);
                        });
                },
                function(err){
                    toastr.error("Error during upload: " + err);
                });
        }

        //Execute fetch of data
        fetch();

    }]);
}());