(function () {
    angular
    .module("RestfulStress")
    .controller("PerformanceController",
    ['$scope', 'trackingService', "requestsCounterInterceptor", "$uibModal", "performanceService", "navigateService", "developerModeService",
    function ($scope, trackingService, requestsCounterInterceptor, $uibModal, performanceService, navigateService, developerModeService) {

        //#region Bindable elements
        var ctrl = this;
        ctrl.isBusy = false;
        ctrl.averageDuration = 0;
        ctrl.maxDuration = 0;
        ctrl.minDuration = 0;
        ctrl.totalIterations = 0;
        ctrl.totalDuration = 0;
        ctrl.successIterations = 0;
        ctrl.errorIterations = 0;
        ctrl.warmupIterations = 0;
        ctrl.totalRequests = 0;
        ctrl.totalResponses = 0;
        ctrl.multiplier = 1;
        ctrl.clientAverageDuration = 0;
        ctrl.clientBestAverageDuration = 0;
        ctrl.serverAverageDuration = 0;
        ctrl.serverBestAverageDuration = 0;
        ctrl.clientThroughput = 0;
        ctrl.bestClientThroughput = 0;
        ctrl.serverThroughput = 0;
        ctrl.bestServerThroughput = 0;
        ctrl.thinkTime = 5000;
        ctrl.interArrivalTime = 0;
        ctrl.arrivalRate = 0;
        ctrl.concurrentUsers = 0;
        ctrl.calculate = calculate;
        ctrl.showPerformanceHelp = showPerformanceHelp;
        ctrl.fillRequestForIterations = fillRequestForIterations;
        ctrl.navigateService = navigateService;
        ctrl.showPeaks = showPeaks;
        ctrl.isDeveloperMode = developerModeService.isEnabled;
        //#endregion

        //Navigate to peaks
        function showPeaks(){

            //Execute navigation
            navigateService.navigate("/peaks");
        }

        //Shows performance help
        function showPerformanceHelp(){

            //Open modal dialog
            $uibModal.open({
                templateUrl: '/help/performanceHelp.html',
                controller: 'PerformanceHelpController as performanceHelpCtrl',
                backdrop: 'static'
            });
        }

        //Fill requests for iterations
        function fillRequestForIterations(){

            //Calculate default multiplier
            ctrl.multiplier = ctrl.totalRequests <= 0 || ctrl.totalIterations <= 0
                ? 1
                :  Math.round(ctrl.totalRequests / ctrl.totalIterations);
        }

        //Calculate current data
        function calculate(){

            //Set busy indicator
            ctrl.isBusy = true;

            //Update stats
            ctrl.averageDuration = trackingService.averageDuration();
            ctrl.bestAverageDuration = trackingService.bestAverageDuration();
            ctrl.maxDuration = trackingService.maxDuration();
            ctrl.minDuration = trackingService.minDuration();
            ctrl.totalDuration = trackingService.totalDuration();
            ctrl.totalIterations = trackingService.totalIterations();
            ctrl.errorIterations = trackingService.totalErrors();
            ctrl.successIterations = ctrl.totalIterations - ctrl.errorIterations;
            ctrl.warmupIterations = trackingService.totalWarmups();

            //Updates counters
            ctrl.totalRequests = requestsCounterInterceptor.totalRequests();
            ctrl.totalResponses = requestsCounterInterceptor.totalResponses();

            //Calculate average durations
            ctrl.clientAverageDuration = performanceService.clientAverageDuration(ctrl.multiplier);
            ctrl.serverAverageDuration = performanceService.serverAverageDuration(ctrl.multiplier);
            ctrl.clientBestAverageDuration = performanceService.clientBestAverageDuration(ctrl.multiplier);
            ctrl.serverBestAverageDuration = performanceService.serverBestAverageDuration(ctrl.multiplier);

            //Calculate throughput
            ctrl.clientThroughput = performanceService.calculateThroughput(ctrl.clientAverageDuration);
            ctrl.serverThroughput = performanceService.calculateThroughput(ctrl.serverAverageDuration);
            ctrl.clientBestThroughput = performanceService.calculateThroughput(ctrl.clientBestAverageDuration);
            ctrl.serverBestThroughput = performanceService.calculateThroughput(ctrl.serverBestAverageDuration);

            //Calculate inter-arrival times
            ctrl.clientInterArrivalTime = performanceService.calculateInterArrivalTime(ctrl.clientAverageDuration, ctrl.thinkTime);
            ctrl.clientBestInterArrivalTime = performanceService.calculateInterArrivalTime(ctrl.clientBestAverageDuration, ctrl.thinkTime);
            ctrl.serverInterArrivalTime = performanceService.calculateInterArrivalTime(ctrl.serverAverageDuration, ctrl.thinkTime);
            ctrl.serverBestInterArrivalTime = performanceService.calculateInterArrivalTime(ctrl.serverBestAverageDuration, ctrl.thinkTime);

            //Calculate arrival rate
            ctrl.clientArrivalRate = performanceService.calculateArrivalRate(ctrl.clientInterArrivalTime);
            ctrl.clientBestArrivalRate = performanceService.calculateArrivalRate(ctrl.clientBestInterArrivalTime);
            ctrl.serverArrivalRate = performanceService.calculateArrivalRate(ctrl.serverInterArrivalTime);
            ctrl.serverBestArrivalRate = performanceService.calculateArrivalRate(ctrl.serverBestInterArrivalTime);

            //Calculate concurrent users
            ctrl.clientConcurrentUsers = performanceService.calculateConcurrentUsers(ctrl.clientThroughput, ctrl.clientArrivalRate);
            ctrl.clientBestConcurrentUsers = performanceService.calculateConcurrentUsers(ctrl.clientBestThroughput, ctrl.clientBestArrivalRate);
            ctrl.serverConcurrentUsers = performanceService.calculateConcurrentUsers(ctrl.serverThroughput, ctrl.serverArrivalRate);
            ctrl.serverBestConcurrentUsers = performanceService.calculateConcurrentUsers(ctrl.serverBestThroughput, ctrl.serverBestArrivalRate);

            //Estimate improvements (empirical) with parallel processing on web server
            ctrl.clientConcurrentUsersMinImprovement = performanceService.estimateMinSimultaneousUsersImprovement(ctrl.clientConcurrentUsers);
            ctrl.clientConcurrentUsersMaxImprovement = performanceService.estimateMaxSimultaneousUsersImprovement(ctrl.clientConcurrentUsers);
            ctrl.clientBestConcurrentUsersMinImprovement = performanceService.estimateMinSimultaneousUsersImprovement(ctrl.clientBestConcurrentUsers);
            ctrl.clientBestConcurrentUsersMaxImprovement = performanceService.estimateMaxSimultaneousUsersImprovement(ctrl.clientBestConcurrentUsers);
            ctrl.serverConcurrentUsersMinImprovement = performanceService.estimateMinSimultaneousUsersImprovement(ctrl.serverConcurrentUsers);
            ctrl.serverConcurrentUsersMaxImprovement = performanceService.estimateMaxSimultaneousUsersImprovement(ctrl.serverConcurrentUsers);
            ctrl.serverBestConcurrentUsersMinImprovement = performanceService.estimateMinSimultaneousUsersImprovement(ctrl.serverBestConcurrentUsers);
            ctrl.serverBestConcurrentUsersMaxImprovement = performanceService.estimateMaxSimultaneousUsersImprovement(ctrl.serverBestConcurrentUsers);

            //Set busy indicator
            ctrl.isBusy = false;
        }

        //Apply settings on service
        function applySettings(){

            //Set values on performance simulations
            performanceService.simulations.multiplier = ctrl.multiplier;
            performanceService.simulations.thinkTime = ctrl.thinkTime;
        }

        //Set multiplier and think time
        ctrl.multiplier = performanceService.simulations.multiplier;
        ctrl.thinkTime = performanceService.simulations.thinkTime;

        //Set watches on variable values
        $scope.$watch(function(){ return ctrl.multiplier; }, applySettings);
        $scope.$watch(function(){ return ctrl.thinkTime; }, applySettings);

        //Execute first calculation
        calculate();
    }]);
}());