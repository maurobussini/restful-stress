(function () {
    angular
    .module("RestfulStress")
    .controller("ScenarioHelpController",
    ['$uibModalInstance',
    function ($uibModalInstance) {

        //#region Bindable elements
        var ctrl = this;
        ctrl.close = close;
        ctrl.data = "$.ajax({\n" +
            "\turl:'https://maps.googleapis.com/maps/api/geocode/json?address=Meran',\n" +
            "\tmethod:'GET',\n" +
            "\tsuccess: function(res){\n" +
            "\t\tdone(res);\n" +
            "\t},\n" +
            "\terror: function(err){\n" +
            "\t\tdone(err);\n" +
            "}});\n";
        //#endregion

        //Closes current dialog
        function close(){
            $uibModalInstance.close();
        }
    }]);
}());