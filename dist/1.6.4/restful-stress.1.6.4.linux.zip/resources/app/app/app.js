(function () {

    var toastr = require('toastr');
    window.toastr = toastr;

    //Angular initializations
    angular
        .module('RestfulStress', [
        'ngRoute',
        'ui.bootstrap',
        'ui.ace'
        ])
        .config(['$routeProvider', '$httpProvider', '$locationProvider','$compileProvider','$provide', config])
        .run(["consoleService", run]);

    // Configuration
    function config($routeProvider, $httpProvider, $locationProvider, $compileProvider, $provide) {

        $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|chrome-extension|filesystem):/);

        $provide.decorator('$sniffer', function($delegate) {
            console.log("$sniffer:" + $delegate.history);
            $delegate.history = false;
            return $delegate;
        });

        $provide.decorator('$window', function($delegate) {
            console.log("$window:" + JSON.stringify($delegate.history));
            $delegate.history = null;
            return $delegate;
        });

        //Remove caching from XHR requests
        $httpProvider.defaults.headers['Cache-Control'] = 'no-cache';
        $httpProvider.defaults.headers['Pragma'] = 'no-cache';

		//Enable cross domain calls
		$httpProvider.defaults.useXDomain = true;
		
		//Remove the header used to identify ajax call  that would prevent CORS from working
		delete $httpProvider.defaults.headers.common['X-Requested-With'];

        //Register interceptors
        $httpProvider.interceptors.push('timeMarkerInterceptor');
        $httpProvider.interceptors.push('requestsCounterInterceptor');
        
        //Home
        $routeProvider.when("/", {
            controller: "HomeController as homeCtrl",
            templateUrl: "app/home/home.html"
        });

        $routeProvider.when("/chart", {
            controller: "ChartController as chartCtrl",
            templateUrl: "app/chart/chart.html"
        });

        $routeProvider.when("/history", {
            controller: "HistoryController as historyCtrl",
            templateUrl: "app/history/history.html"
        });

        $routeProvider.when("/performance", {
            controller: "PerformanceController as performanceCtrl",
            templateUrl: "app/performance/performance.html"
        });

        $routeProvider.when("/storage", {
            controller: "StorageController as storageCtrl",
            templateUrl: "app/storage/storage.html"
        });

        $routeProvider.when("/peaks", {
            controller: "PeaksController as peaksCtrl",
            templateUrl: "app/peaks/peaks.html"
        });

        $routeProvider.when("/scheduler", {
            controller: "SchedulerController as schedulerCtrl",
            templateUrl: "app/scheduler/scheduler.html"
        });

        $routeProvider.when("/tools", {
            controller: "ToolsController as toolsCtrl",
            templateUrl: "app/tools/tools.html"
        });
        
        //Default route
        $routeProvider.otherwise({ redirectTo: "/" });

        //Setting for toastr        
        toastr.options.positionClass = 'toast-top-left';

        //Set localization of "moment.js" in english
        moment.locale('en');

        //Disaable HTML5 mode "PushState"
        $locationProvider.html5Mode(false);

        // var gaService = analytics.getService('restfullStress');
        // var tracker = gaService.getTracker('UA-65082371-1');
        // tracker.sendAppView('MainView');
    }

    //Run execution
    function run(consoleService) {

		console.log("Started");

        //Attach console service
        consoleService.attach();
    }
    
})();