(function () {
    angular
    .module('RestfulStress')
    .factory('developerModeService',
    ['$log',
    function ($log) {

        //Default requests count
        var requestsCount = 0;
        var clickRequired = 10;
        var clickForMessage = 7;

        //Requests activation
        function request(){

            //If default value on counter
            if (requestsCount == 0){

                //Timeout reset of counter (5 seconds)
                setTimeout(function(){

                    //If counter is lower that 10
                    if (requestsCount < clickRequired){

                        //Reset counter
                        requestsCount = 0;
                    }

                }, 5000);
            }

            //Do increment counter
            requestsCount = requestsCount + 1;

            //Show message when near goal
            if (requestsCount == clickForMessage){
                toastr.info("Three more clicks to 'Developer Mode'...");
            }

            //Show message on activation
            if (requestsCount >= clickRequired){
                toastr.success("Developer Mode is enabled!");
            }
        }

        //Returns "isEnabled" flag
        function isEnabled(){

            //Is enabled if requests is >= 10
            return requestsCount >= clickRequired;
        }

        //Returns service schema
        return {
            isEnabled: isEnabled,
            request: request
        };

    }]);
}());