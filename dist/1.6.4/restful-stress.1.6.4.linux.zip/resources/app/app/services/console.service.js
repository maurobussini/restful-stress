(function () {
    angular
    .module('RestfulStress')
    .factory('consoleService',
    ['$log',
    function ($log) {

        //Messages on console
        var messages = [];

        /**
         * Attaches console to current service
         */
        function attach(){

            //Get standard console
            var oldf = console.log;

            //Redefine console function    
            console.log = function(){
                messages.push(arguments);
                oldf.apply(console, arguments);
            }
        }

        /**
         * Fetch messages
         */
        function fetchMessages(){

            //Returns messages
            return messages;
        }
        
        //Returns service schema
        return {
            fetchMessages: fetchMessages,
            attach: attach
        };

    }]);
}());