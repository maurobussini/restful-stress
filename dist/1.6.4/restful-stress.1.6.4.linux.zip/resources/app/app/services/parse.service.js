(function () {
    angular
    .module('RestfulStress')
    .factory('parseService',
    ['$log',
    function ($log) {

        //Checks if provided string is JSON
        function isJson(sourceString){

            try{

                //Try parse source string
                JSON.parse(sourceString);

                //Confirm that is JSON
                return true;
            }
            catch(ex){

                //Returns false
                return false;
            }
        }

        /**
         * Converts a base-64 string to binary array
         * @param b64Data Base64 string
         * @returns {*} Returns binary array
         */
        function base64ToBinaryArray(b64Data) {

            //Arguments validation
            if (!b64Data){
                return null;
            }

            //Converts to array
            var data = atob(b64Data)

            //Length of data: create buffer and array
            var length = data.length;
            var buf = new ArrayBuffer(length);
            var arr = new Uint8Array(buf);

            //Iterate and create char elements
            for (var i = 0; i < length; i++) {
                arr[i] = data.charCodeAt(i);
            }

            //Returns buffer
            return buf;
        }

        /**
         * Converts base64 string to Blob
         * @param b64Data Base64 string
         * @param contentType Content type (default 
         * @param fileName
         * @param sliceSize
         * @returns {*}
         */
        function base64toBlob(b64Data, contentType, fileName, sliceSize) {

            //Set defaults
            contentType = contentType || '';
            sliceSize = sliceSize || 512;
            fileName = fileName || 'file.name';

            //Converts base64 to array
            var byteCharacters = atob(b64Data);
            var byteArrays = [];

            //Iterate data on array
            for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {

                //Get slice
                var slice = byteCharacters.slice(offset, offset + sliceSize);

                //Create new array and set data
                var byteNumbers = new Array(slice.length);
                for (var i = 0; i < slice.length; i++) {
                    byteNumbers[i] = slice.charCodeAt(i);
                }

                //Array for current slice
                var byteArray = new Uint8Array(byteNumbers);

                //Push to target
                byteArrays.push(byteArray);
            }

            //Creates and return blob
            var blob = new Blob(byteArrays, { type: contentType, name: fileName });
            return blob;
        }

        //Returns service schema
        return {
            isJson: isJson,
            base64ToBinaryArray: base64ToBinaryArray,
            base64toBlob: base64toBlob
        };

    }]);
}());