(function () {
    angular
    .module('RestfulStress')
    .factory('navigateService',
    ['$log', '$location',
    function ($log, $location) {

        // Navigates to provided url
        function navigate(url) {
            $location.path(url);
        }

        /**
         * Opens url in external browser
         * 
         * @param {any} url URL
         */
        function openInBrowser(url) {
        
            const { shell } = require('electron');
            shell.openExternal(url);            
        }

        //Returns service schema
        return {
            navigate: navigate,
            openInBrowser: openInBrowser
        };

    }]);
}());