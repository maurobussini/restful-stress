(function () {
    angular
    .module('RestfulStress')
    .factory('neuralService',
    ['$log',
    function ($log) {

        var brainInstance = null;

        function trainBrain(trainData){

            brainInstance = new brain.NeuralNetwork();

            /*
            brainInstance.train([
                {input: [0, 0], output: [0]},
                {input: [0, 1], output: [1]},
                {input: [1, 0], output: [1]},
                {input: [1, 1], output: [0]}
            ]);
            */

            brainInstance.train(trainData);

        }

        function runBrain(input){

            //Arguments validation
            if (typeof input === 'undefined')
                throw new Error("Argument 'input' is invalid");

            //Check if brain was initialized
            if (!brainInstance)
                throw new Error("Neural network was not initialized");

            var result = brainInstance.run([input]);  // [1, 0] => [0.987]
            return result[0];
        }

        function run(input){

        }


        //Trains network using provided inputs and outputs
        function train(trainingData){

            //Arguments validation
            if (!trainingData)
                throw new Error("Argument 'trainingData' is invalid");

            //Check if data has valid elements
            if (trainingData.length == 0)
                throw new Error("Provided training data is empty");

            //Iterate all over data
            for (var i = 0; i < trainingData.length; i++){



            }

        }

        //Returns service schema
        return {
            train: train,
            run: run,
            trainBrain: trainBrain,
            runBrain: runBrain
        };

    }]);
}());