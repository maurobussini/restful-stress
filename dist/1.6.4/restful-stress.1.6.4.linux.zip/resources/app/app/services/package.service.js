(function () {
    angular
    .module('RestfulStress')
    .factory('packageService',
    ['atomAdapterService', 'scenarioAdapterService', 'massiveAdapterService', 'engineService',
    function (atomAdapterService, scenarioAdapterService, massiveAdapterService, engineService) {

        /**
         * Build package with current settings
         */
        function build(){

            //Create package of data
            var package = {
                registrationDate: moment().format(),
                atom: atomAdapterService.getSettings(),
                scenario: scenarioAdapterService.settings,
                massive: massiveAdapterService.settings,
                engine: engineService.getSettings()
            };

            //Returns package
            return package;
        }


        //Returns service schema
        return {
            build: build
        };

    }]);
}());