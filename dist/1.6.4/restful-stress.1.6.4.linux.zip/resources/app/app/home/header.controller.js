(function () {
    angular
    .module("RestfulStress")
    .controller("HeaderController",
    ["navigateService", "developerModeService", "githubService",
    function (navigateService, developerModeService, githubService) {

        //#region Bindable elements
        var ctrl = this;
        ctrl.navigateService = navigateService;
        ctrl.title = '';
        ctrl.version = '';
        ctrl.lastVersion = '';
        ctrl.send = function(){
            coordinatorService.send();
        }
        ctrl.labCounter = 0;
        ctrl.requestDeveloperMode = requestDeveloperMode;
        ctrl.isDeveloperMode = false;        
        ctrl.openInBrowser = navigateService.openInBrowser;
        ctrl.isUpdateAvailable = false;
        ctrl.navigateToGitHubReleases = navigateToGitHubReleases;
        //#endregion

        //Do apply developer mode
        function requestDeveloperMode(){

            //Request developer mode (at least tries...)
            developerModeService.request();

            //Get "isEnabled" flag
            ctrl.isDeveloperMode = developerModeService.isEnabled();
        }

        //Get manifest
        ctrl.version = require('electron').remote.app.getVersion();
        ctrl.title = "RESTful Stress";
	    //ctrl.version = manifest.version;

        /**
         * Check last available version
         */
        function checkVersion(){

            //Get last version from server
            ctrl.isUpdateAvailable = false;
            githubService.getLastAvailableVersion().then(function(data){

                //Set available version
                ctrl.lastVersion = !data ? "-" : data.version;

                //Check update if we have data
                if (data && data.version) {

                    //If new version is greater, show message
                    if (githubService.isVersionGreater(data.version, ctrl.version)){

                        //Set update available
                        ctrl.isUpdateAvailable = true;

                        //Show message
                        toastr.info(
                            "New version (v" + data.version + ") is available on GitHub!\n" + 
                            "Click on this message to navigate to download page...",
                            "Update available", {
                            "closeButton": true,  
                            "progressBar": true,
                            "timeOut": "10000",
                            "onclick": navigateToGitHubReleases
                        });
                    }
                }
            });
        }

        /**
         * Navigate to GitHub releases
         * 
         */
        function navigateToGitHubReleases(){

            //Uses service to navigate
            navigateService.openInBrowser("https://github.com/maurobussini/restful-stress");
        }

        //Check last version on GitHub
        checkVersion();

    }]);
}());