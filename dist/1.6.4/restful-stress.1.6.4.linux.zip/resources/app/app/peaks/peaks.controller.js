(function () {
    angular
    .module("RestfulStress")
    .controller("PeaksController",
    ['$scope', '$routeParams', 'trackingService', "performanceService", "navigateService",
    function ($scope, $routeParams, trackingService, performanceService, navigateService) {

        //#region Bindable elements
        var ctrl = this;
        ctrl.isBusy = false;
        ctrl.concurrentUsers = 0;
        ctrl.parallelIndicator = 0;
        ctrl.worstAverageSessionDuration = 0;
        ctrl.bestAverageSessionDuration = 0;
        ctrl.worstAverageDuration = 0;
        ctrl.bestAverageDuration = 0;
        ctrl.simulatedAverageDuration = 0;
        ctrl.worstThroughput = 0;
        ctrl.bestThroughput = 0;
        ctrl.simulatedThroughput = 0;
        ctrl.worstInterArrivalTime = 0;
        ctrl.bestInterArrivalTime = 0;
        ctrl.simulatedInterArrivalTime = 0;
        ctrl.worstArrivalRate = 0;
        ctrl.bestArrivalRate = 0;
        ctrl.simulatedArrivalRate = 0;
        ctrl.worstVisitorsPerHour = 0;
        ctrl.bestVisitorsPerHour = 0;
        ctrl.simulatedVisitorsPerHour = 0;
        ctrl.worstVisitorsPerMinute = 0;
        ctrl.bestVisitorsPerMinute = 0;
        ctrl.simulatedVisitorsPerMinute = 0;
        ctrl.calculate = calculate;
        ctrl.showPerformances = showPerformances;
        //#endregion

        //Navigate to performance
        function showPerformances(){

            //Execute navigation
            navigateService.navigate("/performance");
        }

        //Calculate current data
        function calculate(){

            //Set busy indicator
            ctrl.isBusy = true;

            //Calculate average duration of workflow (on server side)
            ctrl.worstAverageDuration = performanceService.serverAverageDuration(ctrl.multiplier);
            ctrl.bestAverageDuration = performanceService.serverBestAverageDuration(ctrl.multiplier);

            //Calculate average duration of workflow (on server side)
            ctrl.worstAverageSessionDuration = performanceService.serverAverageDuration(1);
            ctrl.bestAverageSessionDuration = performanceService.serverBestAverageDuration(1);
            ctrl.simulatedAverageSessionDuration = ctrl.simulatedAverageDuration * ctrl.multiplier;

            //Calculate throughput
            ctrl.worstThroughput = performanceService.calculateThroughput(ctrl.worstAverageDuration);
            ctrl.bestThroughput = performanceService.calculateThroughput(ctrl.bestAverageDuration);
            ctrl.simulatedThroughput = performanceService.calculateThroughput(ctrl.simulatedAverageDuration);

            //Calculate inter-arrival time
            ctrl.worstInterArrivalTime = performanceService.calculateInterArrivalTime(ctrl.worstAverageDuration, ctrl.thinkTime);
            ctrl.bestInterArrivalTime = performanceService.calculateInterArrivalTime(ctrl.bestAverageDuration, ctrl.thinkTime);
            ctrl.simulatedInterArrivalTime = performanceService.calculateInterArrivalTime(ctrl.simulatedAverageDuration, ctrl.thinkTime);

            //Calculate arrival rate
            ctrl.worstArrivalRate = performanceService.calculateArrivalRate(ctrl.worstInterArrivalTime);
            ctrl.bestArrivalRate = performanceService.calculateArrivalRate(ctrl.bestInterArrivalTime);
            ctrl.simulatedArrivalRate = performanceService.calculateArrivalRate(ctrl.simulatedInterArrivalTime);

            //Calculate concurrent users
            ctrl.worstConcurrentUsers = performanceService.calculateConcurrentUsers(ctrl.worstThroughput, ctrl.worstArrivalRate);
            ctrl.bestConcurrentUsers = performanceService.calculateConcurrentUsers(ctrl.bestThroughput, ctrl.bestArrivalRate);
            ctrl.simulatedConcurrentUsers = performanceService.calculateConcurrentUsers(ctrl.simulatedThroughput, ctrl.simulatedArrivalRate);

            //Visitors per hour is equals to concurrent user multiply number of visits in 1 hour
            // => VH = Visitors per hour
            // => CU = Concurrent users
            // => AD = Average duration (minutes)
            // => VH = CU * (60 / AD)
            ctrl.worstVisitorsPerHour = performanceService.calculateVisitorsPerHour(ctrl.worstConcurrentUsers, ctrl.worstAverageSessionDuration);
            ctrl.bestVisitorsPerHour = performanceService.calculateVisitorsPerHour(ctrl.bestConcurrentUsers, ctrl.bestAverageSessionDuration);
            ctrl.simulatedVisitorsPerHour = performanceService.calculateVisitorsPerHour(ctrl.simulatedConcurrentUsers, ctrl.simulatedAverageSessionDuration);

            //Calculate per minutes
            ctrl.worstVisitorsPerMinute = performanceService.calculateVisitorsPerMinute(ctrl.worstConcurrentUsers, ctrl.worstAverageSessionDuration);
            ctrl.bestVisitorsPerMinute = performanceService.calculateVisitorsPerMinute(ctrl.bestConcurrentUsers, ctrl.bestAverageSessionDuration);
            ctrl.simulatedVisitorsPerMinute = performanceService.calculateVisitorsPerMinute(ctrl.simulatedConcurrentUsers, ctrl.simulatedAverageSessionDuration);


            //ESTIMATED PARALLEL

            //Calculate throughput with parallel indicator values
            ctrl.worstEstimatedParallelThroughput = performanceService.estimateParallelThroughput(ctrl.worstThroughput, ctrl.parallelIndicator);
            ctrl.bestEstimatedParallelThroughput = performanceService.estimateParallelThroughput(ctrl.bestThroughput, ctrl.parallelIndicator);
            ctrl.simulatedEstimatedParallelThroughput = performanceService.estimateParallelThroughput(ctrl.simulatedThroughput, ctrl.parallelIndicator);

            //Calculate concurrent users with parallel indicator values
            ctrl.worstEstimatedParallelConcurrentUsers = performanceService.calculateConcurrentUsers(ctrl.worstEstimatedParallelThroughput, ctrl.worstArrivalRate);
            ctrl.bestEstimatedParallelConcurrentUsers = performanceService.calculateConcurrentUsers(ctrl.bestEstimatedParallelThroughput, ctrl.bestArrivalRate);
            ctrl.simulatedEstimatedParallelConcurrentUsers = performanceService.calculateConcurrentUsers(ctrl.simulatedEstimatedParallelThroughput, ctrl.simulatedArrivalRate);

            //Visitors per hour with parallel indicator values
            ctrl.worstEstimatedParallelVisitorsPerHour = performanceService.calculateVisitorsPerHour(ctrl.worstEstimatedParallelConcurrentUsers, ctrl.worstAverageSessionDuration);
            ctrl.bestEstimatedParallelVisitorsPerHour = performanceService.calculateVisitorsPerHour(ctrl.bestEstimatedParallelConcurrentUsers, ctrl.bestAverageSessionDuration);
            ctrl.simulatedEstimatedParallelVisitorsPerHour = performanceService.calculateVisitorsPerHour(ctrl.simulatedEstimatedParallelConcurrentUsers, ctrl.simulatedAverageSessionDuration);

            //Calculate per minutes with parallel indicator values
            ctrl.worstEstimatedParallelVisitorsPerMinute = performanceService.calculateVisitorsPerMinute(ctrl.worstEstimatedParallelConcurrentUsers, ctrl.worstAverageSessionDuration);
            ctrl.bestEstimatedParallelVisitorsPerMinute = performanceService.calculateVisitorsPerMinute(ctrl.bestEstimatedParallelConcurrentUsers, ctrl.bestAverageSessionDuration);
            ctrl.simulatedEstimatedParallelVisitorsPerMinute = performanceService.calculateVisitorsPerMinute(ctrl.simulatedEstimatedParallelConcurrentUsers, ctrl.simulatedAverageSessionDuration);

            //Set busy indicator
            ctrl.isBusy = false;
        }

        //Set multiplier and think time
        ctrl.multiplier = performanceService.simulations.multiplier;
        ctrl.thinkTime = performanceService.simulations.thinkTime;
        ctrl.parallelIndicator = performanceService.simulations.parallelIndicator;

        //Apply settings on service
        function applySettings(){

            //Set values on performance simulations
            performanceService.simulations.multiplier = ctrl.multiplier;
            performanceService.simulations.thinkTime = ctrl.thinkTime;
            performanceService.simulations.parallelIndicator = ctrl.parallelIndicator;
        }

        //Set watches on variable values
        $scope.$watch(function(){ return ctrl.multiplier; }, applySettings);
        $scope.$watch(function(){ return ctrl.thinkTime; }, applySettings);
        $scope.$watch(function(){ return ctrl.parallelIndicator; }, applySettings);

        //Execute first calculation
        calculate();

    }]);
}());