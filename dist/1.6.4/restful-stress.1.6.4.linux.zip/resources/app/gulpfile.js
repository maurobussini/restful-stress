const gulp = require('gulp');
const zip = require('gulp-zip');
const run = require('gulp-run');
const clean = require('gulp-clean');
const rename = require("gulp-rename");
const jslinq = require("jslinq");
const moment = require("moment");
const fs = require("fs");

let package = require('./package.json');

//*** CLEAN ***
gulp.task('clean:win', () => {
    return gulp.src([
        "./dist/tmp/win", 
        "./dist/builds/" + package.productName + "-win32-ia32", 
        "./dist/installers/win"], 
        { read: false })
        .pipe(clean());
});
gulp.task('clean:mac', () => {
    return gulp.src([
        "./dist/tmp/mac", 
        "./dist/builds/" + package.productName + "-darwin-x64", 
        "./dist/installers/mac"], 
        { read: false })
        .pipe(clean());
});
gulp.task('clean:linux', () => {
    return gulp.src([
        "./dist/tmp/linux", 
        "./dist/builds/" + package.productName + "-linux-x64", 
        "./dist/installers/linux"], 
        { read: false })
        .pipe(clean());
});

//*** TEMP ***
gulp.task('tmp:win', ['clean:win'], () => {
    return gulp.src([
        "**/*.*", 
        "!certificates/**/*.*",
        "!dist/**/*.*", 
        "!installers/**/*.*"])
        .pipe(gulp.dest('dist/tmp/win'));
});
gulp.task('tmp:mac', ['clean:mac'], () => {
    return gulp.src([
        "**/*.*", 
        "!certificates/**/*.*",
        "!dist/**/*.*", 
        "!installers/**/*.*"])
        .pipe(gulp.dest('dist/tmp/mac'));
});
gulp.task('tmp:linux', ['clean:linux'], () => {
    return gulp.src([
        "**/*.*", 
        "!certificates/**/*.*",
        "!dist/**/*.*", 
        "!installers/**/*.*"])
        .pipe(gulp.dest('dist/tmp/linux'));
});

//*** BUILD ***
gulp.task('build:win', ['tmp:win'], () => {
    return run('npm run build:win').exec();
});
gulp.task('build:mac', ['tmp:mac'], () => {
    return run('npm run build:mac').exec();
});
gulp.task('build:linux', ['tmp:linux'], () => {
    return run('npm run build:linux').exec();
});
gulp.task('build:versions', () => {
    let source = "./versions.json";
    let versions = require(source);
    let current = jslinq(versions)
        .singleOrDefault(v => v.version == package.version);
    if (current){
        versions = jslinq(versions)
            .remove(current)
            .toList();
    }
    versions.push({ 
        version: package.version, 
        releaseDate: moment().format('YYYY-MM-DD')
    });
    fs.writeFile(source, JSON.stringify(versions, null, "   "), (err) => {
        console.log(!err ? "Versions updated" : "Versions failed");
    });
});

//*** INSTALLER ***
gulp.task('installer:win', ['build:win'], () => {
    return run('npm run installer:win').exec();
});
gulp.task('installer:mac', ['build:mac'], () => {
    return run('npm run installer:mac').exec();
});
gulp.task('installer:linux', ['build:linux'], () => {
    var fileName = package.productName + ".linux.zip";
	var sourceFolder = 'dist/builds/' + package.productName + "-linux-x64";
    return gulp.src([
		sourceFolder + "/**/*", 
		"!" + sourceFolder + "/resources/app/certificates/**/*.*", 
		"!" + sourceFolder + "/resources/app/dist/**/*.*"
		])
        .pipe(zip(fileName))
        .pipe(gulp.dest('dist/installers/linux'));
});

//COPY
gulp.task('release:win', ['installer:win'], () => {
    var fileName = package.productName + "." + package.version + ".win.exe";    
    return gulp.src('dist/installers/win/' + package.productName + "." + package.version + ".installer.exe")        
        .pipe(rename(fileName))
        .pipe(gulp.dest('dist/releases/'));
});
gulp.task('release:linux', ['installer:linux'], () => {
    var fileName = package.productName + "." + package.version + ".linux.zip";    
    return gulp.src('dist/installers/linux/' + package.productName + ".linux.zip")        
        .pipe(rename(fileName))
        .pipe(gulp.dest('dist/releases/'));
});
gulp.task('release:mac', ['installer:mac'], () => {
    var fileName = package.productName + "." + package.version + ".mac.dmg";    
    return gulp.src('dist/installers/mac/' + package.productName + "." + package.version + ".dmg")        
        .pipe(rename(fileName))
        .pipe(gulp.dest('dist/releases/'));
});

//DEPLOY
gulp.task('deploy:versions', ['build:versions'], () => {
    return gulp.src("./versions.json")
        .pipe(gulp.dest('../../public/restful-stress'));
});
gulp.task('deploy:all', ['release:win', 'release:linux', 'deploy:versions'], ()=>{
    return gulp.src("./dist/releases/*.*")
        .pipe(gulp.dest('../../public/restful-stress/dist/' + package.version));
});

