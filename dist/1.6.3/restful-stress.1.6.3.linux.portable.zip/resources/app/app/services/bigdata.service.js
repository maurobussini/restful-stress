(function () {
    angular
    .module('RestfulStress')
    .factory('bigdataService',
    ['$log', '$q',
    function ($log, $q) {

        /**
         *
         */
        function push(dataToPush){



        }

        //Returns service schema
        return {
            push: push
        };

    }]);
}());