(function () {
    angular
    .module('RestfulStress')
    .factory('runService',
    ['$q',
    function ($q) {

        var executionTimeout = 60000;

        /**
         * Runs script
         * @param scriptString Script
         * @returns {*} Returns promise
         */
        function run(scriptString){

            //Create promise
            var defer = $q.defer();

            //Compile code and launch it
            compile(scriptString).then(
                function(res){
                    defer.resolve(res);
                });

            //Returns promise
            return defer.promise;
        }

        //Do compile of code on scenario without execute
        function compile(scriptString){

            //Create promise
            var defer = $q.defer();

            //Fail function: resolve with error
            var failFn = function(error){
                defer.resolve(error);
            };

            //Check previous file existence
            var existsFn = function(fs){

                //Remove file if exists
                fs.root.getFile('run.script', { create: false },
                    function doesExists(){

                        //Delete previous
                        delFn(fs);
                    },
                    function doesNotExists(){

                        //Do initialize
                        initFn(fs);
                    }
                );
            };

            //Delete previous
            var delFn = function(fs){

                //Remove file if exists
                fs.root.getFile('run.script', { create: false }, function(entryToDelete){
                    entryToDelete.remove(function(){

                        //Create
                        initFn(fs);
                    });
                }, failFn);
            };

            //Init function
            var initFn = function(fs){

                //Request create of temporary file
                fs.root.getFile('run.script', { create: true, exclusive: false }, function(fileEntry) {

                    //A file is created with these properties
                    // fileEntry.isFile === true
                    // fileEntry.name == 'buildScenario.scenario'
                    // fileEntry.fullPath == '/buildScenario.scenario'

                    //Creare a writer to into it
                    fileEntry.createWriter(function(fileWriter) {

                        //Do fail on error
                        fileWriter.onerror = failFn;

                        //Get full name (URL) of file
                        var urlo = fileEntry.toURL();

                        //On end of write of temporary file
                        fileWriter.onwriteend = function() {

                            //Try compile (errors can exists)
                            try{

                                //Dynamically load a script using the file (local) URL
                                $.getScript(urlo, function(data, textStatus, jqxhr)
                                {
                                    //Script is now loaded and executed.

                                    //Try execution that can throw unhandled exception
                                    try{

                                        //Set a timeout for long executions; maybe the
                                        //user code do not invoke "done": in that case
                                        //the environment will fail in 10 seconds

                                        //Run setTimeout
                                        setTimeout(function(){

                                            //Resolve with timeout
                                            defer.resolve("timeout error: your script " +
                                                "took more than " + (executionTimeout / 1000) + " seconds");

                                        }, executionTimeout);

                                        //Execute compiled scenario
                                        window.compiledScript(function(doneResult){

                                            //Generate result and resolve promise
                                            var processedResult = generateResult(doneResult);
                                            defer.resolve(processedResult);
                                        });
                                    }
                                    catch(unhandledException){

                                        //Resolve compile exception
                                        defer.resolve({
                                            isSuccess: false,
                                            status: 0,
                                            data: "unhandled exception:" + unhandledException.message
                                        });
                                    }
                                });
                            }
                            catch(compileException){

                                //Resolve compile exception
                                defer.resolve({
                                    isSuccess: false,
                                    status: 0,
                                    data: "compile exception:" + compileException.message
                                });
                            }
                        };

                        //Define all JavaScript code to compile
                        var fullJsCode = "window.compiledScript = " +
                            "function(done){" + scriptString + "};";

                        //Create a new Blob and write scenario code to it
                        var blob = new Blob([fullJsCode], {type: 'text/plain'});
                        fileWriter.write(blob);

                    }, failFn);

                }, failFn);

            };

            //Request HTML5 fileSystem API and access to fs on temporary area
            window.requestFileSystem  = window.requestFileSystem || window.webkitRequestFileSystem;
            window.requestFileSystem(window.TEMPORARY, 5*1024*1024, existsFn, failFn);

            //Returns promise
            return defer.promise;
        }

        //Returns schema
        return {
            run: run
        };

    }]);
}());
