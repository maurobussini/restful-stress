(function () {
    angular
    .module('RestfulStress')
    .factory('httpRequestService',
    ['$log', '$http', '$q', 'parseService', '$timeout',
    function ($log, $http, $q, parseService, $timeout) {

        /**
         * Re-sync headers with provided body kind
         * @param headers Existing headers
         * @param bodyKind Body kind
         */
        function syncHeaderWithBodyKind(settings){
            
            //Arguments validation
            if (!settings) throw new Error("Argument 'settings' is invalid");

            //Get headers and body kind
            var bodyKind = settings.bodyKind;
            var jsonHeaders = settings.headers;

            //if not JSON, just exit
            if (!parseService.isJson(jsonHeaders)){
                return;
            }

            //Headers are in JSON, convert
            var headers = JSON.parse(jsonHeaders);

            //Try to get 'Content-Type' header
            var contentType = headers['Content-Type'];

            //Define values
            var wwwContentType = "application/x-www-form-urlencoded; charset=utf-8";
            var formContentType = "multipart/form-data; charset=utf-8";
            var jsonContentType = "application/json; charset=utf-8";

            //Select by bodyKind
            switch(bodyKind){

                case 'x-www-form-urlencoded':
                    contentType = wwwContentType;
                    break;

                case 'form-data':
                    contentType = formContentType;
                    break;

                case 'json': 
                    contentType = jsonContentType;
                    break;

                default: //Custom                    
                    break;
            }

            //If current value is synced with
            //the bodyKind, return without change
            if (headers['Content-Type'] == contentType){
                return;
            }

            //Set on headers
            headers['Content-Type'] = contentType;

            //Converts headers to json and set
            jsonHeaders = JSON.stringify(headers, null, '   ');
            settings.headers = jsonHeaders;
            $log.debug("Headers updated!");
        }

        //Executes invoke on remote server
        function invoke(url, verb, body, headers, withCredentials, timeout){

            //Arguments validation
            if (!url) throw new Error("Argument 'url' is invalid");
            if (!verb) throw new Error("Argument 'verb' is invalid");

            //Create promise
            var defer = $q.defer();

            var bodyObj = null;
            var headersObj = null;

            //If body is JSON, convert
            if (parseService.isJson(body)){

                //Do parse or default values
                bodyObj = JSON.parse(body) || null;
            }
            else{

                //Just set value or default
                bodyObj = body;
            }

            //Is headers is JSON, convert
            if (parseService.isJson(headers)){

                //Do parse or default values
                headersObj = JSON.parse(headers) || {};
            }
            else{

                //Just set value or default
                headersObj = headers;
            }

            //Convert to JSON headers and body (IF NOT JSON)
            //var bodyObj = body ?  JSON.parse(body) : null;
            //var headersObj = headers ? JSON.parse(headers) : {};

            //Compose request for remote invoke
            var request = {
                url: url,
                method: verb,
                data: bodyObj,
                headers: headersObj,
                withCredentials: withCredentials,
                isHandledXhrRequest: true
            };
			
            //Try to get "Content-Type" header
            var contentTypeHeader = headersObj 
                ? headersObj["Content-Type"] 
                : null;
                
            //If "Content-Type" exists
            if (contentTypeHeader){

                //Set transformer according with header "ContentType" => "application/x-www-form-urlencoded"
                if (contentTypeHeader.indexOf("application/x-www-form-urlencoded") >= 0){
                    request.transformRequest = convertBodyObjectToEncodedUrl;
                }

                //Set transformer according with header "ContentType" => "multipart/form-data"
                if (contentTypeHeader.indexOf("multipart/form-data") >= 0){

                    //Set transform function
                    request.transformRequest = convertBodyObjectToFormData;

                    //Remove header so the browser set automatically the
                    //correct content type using provided body
                    headersObj["Content-Type"] = undefined;
                }
            }

            //Invoke asynchronous XHR
			var promise = $http(request).then(

				//Success
				function (response) {

                    //Resolve promise
                    defer.resolve({
						request: request,
						start: response.config.timestamp.start,
						duration: response.config.timestamp.duration,
						data: response.data,
						status: response.status,
                        isSuccess: true
                    });
				},

				//Error
				function (error) {

                    //Resolve promise
                    defer.resolve({
                        request: request,
						start: error.config.timestamp.start,
						duration: error.config.timestamp.duration,
                        data: error,
						status: error.status,
                        isSuccess: false
                    });
                });

            //If timeout is invalid, set default to 30 seconds
            if (!timeout)
                timeout = 10000;

            //TIMEOUT VA QUI

            //Set timeout for fail
            var currentTime = new Date();
            $timeout(function(){

                //Resolve with fail after timeout
                defer.resolve({
                    request: request,
                    start: currentTime,
                    duration: timeout,
                    data: 'Timeout after ' + timeout + " milliseconds",
                    status: 0,
                    isSuccess: false
                });

            }, timeout);

            //Returns promise
            return defer.promise;
        }

        /**
         * Converts body object to www-encoded url
         * @param bodyObject Body object
         * @returns {*} Returns converted value
         */
        function convertBodyObjectToEncodedUrl(bodyObject){

            // If this is not an object, defer to native stringification.
            if (!angular.isObject(bodyObject)) {
                return bodyObject == null  ? "" : bodyObject.toString();
            }

            //Out array
            var outArray = [];

            //Iterate elements and encode property and value
            for(var currentBodyElement in bodyObject){

                //If not property of element, continue
                if (!bodyObject.hasOwnProperty(currentBodyElement)){
                    continue;
                }

                //Current property name and value
                var currentPropertyName = currentBodyElement;
                var currentPropertyValue = bodyObject[currentPropertyName];

                //Encode property name and value
                var encodedPropertyName = encodeURIComponent(currentPropertyName);
                var encodedPropertyValue = encodeURIComponent(currentPropertyValue == null ? "" : currentPropertyValue);

                //Push to array
                outArray.push(encodedPropertyName + "=" + encodedPropertyValue);
            }

            //Join strings with "&" and replace spaces
            var queryString = outArray
                .join("&")
                .replace(/%20/g, "+");
            return queryString;
        }

        /**
         * Converts body object to form data
         * @param bodyObject Body object
         * @returns {*} Returns converted value
         */
        function convertBodyObjectToFormData(bodyObject){

            //Creates form data
            var formData = new FormData();

            //If object is empty, return
            if (!bodyObject){
                return formData;
            }

            //We need to convert our json object to a string version of
            //json otherwise the browser will do a 'toString()' on the
            //object which will result in the value '[Object object]' on the server.

            //Iterate elements on source object
            for (var currentBodyElement in bodyObject){

                //Current property name and value
                var currentPropertyName = currentBodyElement;
                var currentPropertyValue = bodyObject[currentPropertyName];

                //If current value is object, convert to JSON
                if (typeof currentPropertyValue == 'object'){
                    currentPropertyValue = JSON.stringify(currentPropertyValue);
                }

                //If current element name starts with "file", convert to Blob
                if (currentPropertyName.indexOf("file") == 0){
                    currentPropertyValue = parseService.base64toBlob(currentPropertyValue);
                }

                //Append element to form-data
                formData.append(currentPropertyName, currentPropertyValue);
            }

            //Returns form data
            return formData;
        }

        //Returns service schema
        return {
            invoke: invoke,
            syncHeaderWithBodyKind: syncHeaderWithBodyKind
        };

    }]);
}());