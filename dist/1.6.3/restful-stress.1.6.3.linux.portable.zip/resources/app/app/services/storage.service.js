(function () {
    angular
    .module('RestfulStress')
    .factory('storageService',
    ['$log','$q',
    function ($log, $q) {

        //Requires
        var fs = require("fs");
        var path = require("path");

        //Compose local path
        var currentWorkingPath = process.cwd();
        var folder = path.join(currentWorkingPath , "data");
        var fileName = path.join(folder, "storage.json");

        //Loads data from storage and returns promise
        function load(){

            //Create promise
            var defer = $q.defer();

            ensureFolder();

            //Try to read file
            fs.readFile(fileName, 'UTF-8', function(err, data) {

                //With error, returns empty
                if (err){

                    //Empty array
                    defer.resolve([]);
                    return;
                }

                //Read as JSON
                var values = JSON.parse(data);
                defer.resolve(values);
            });

            // //Try to get data from chrome
            // //OLD => chrome.storage.sync
            // chrome.storage.local.get("value", function (data){

            //     //Try to get "value" from object
            //     var value = data["value"];

            //     //If element is not array, returns empty
            //     var returnData = Array.isArray(value)
            //         ? value
            //         : [];

            //     //Resolve promise
            //     defer.resolve(returnData);
            // });

            //Returns promise
            return defer.promise;
        }

        function ensureFolder(){
            if (!fs.existsSync(folder)){
                fs.mkdirSync(folder);
            }
        }


        //Saves data to storage
        function save(data){

            //Arguments validation
            if (!data) throw new Error('Argument "data" is invalid.');

            //Create promise
            var defer = $q.defer();

            //Convert in JSON
            var json = JSON.stringify(data, null, "   ");

            ensureFolder();

            //Try to read file
            fs.writeFile(fileName, json, function(err) {

                //With error, reject
                if (err){

                    //Message
                    defer.reject(err.message);
                    return;
                }

                //Confirm write
                defer.resolve('Data saved');
            });

            // //Se data on Chrome storage
            // //OLD => chrome.storage.sync
            // chrome.storage.local.set({ 'value': data }, function(){

            //     //If error
            //     if (chrome.runtime.lastError){

            //         //Reject promise
            //         defer.reject(chrome.runtime.lastError.message);
            //     }
            //     else{

            //         //Resolve promise
            //         defer.resolve('Data saved');
            //     }
            // });

            //Returns promise
            return defer.promise;
        }

        //Appends single element
        function append(single){

            //Create promise
            var defer = $q.defer();

            //Load data on storage
            load().then(function(data){

                //Append single element
                data.push(single);

                //Execute save
                save(data).then(
                    function(saveData){

                        //Resolve promise
                        defer.resolve(saveData);
                    },
                    function(err){

                        //Reject promise
                        defer.reject(err);
                    })
            });

            //Returns promise
            return defer.promise;
        }

        //Returns service schema
        return {
            append: append,
            load: load,
            save: save
        };

    }]);
}());