(function () {
    angular
    .module('RestfulStress')
    .factory('trackingService',
    ['$log', '$q',
    function ($log, $q) {

        var trackings = [];

        /**
         * url: url,
         * verb: verb,
         * data: data,
         * headers: headers
         *
         * request => object,
         * data => string,
         * status => number,
         * start: => date,
         * duration => number
         * isSuccess => boolean
         * isWarmup => boolean
        **/

        function all(){
            return trackings;
        }

        //Count elements
        function count(){

            //Create promise
            var defer = $q.defer();

            //Resolve with length of array
            defer.resolve(trackings.length);

            //Returns promise
            return defer.promise;
        }

        //Pushes a new element on tracking
        function push(item){

            //Push item
            trackings.push(item);
        }

        //Fetch tracked items
        function fetch(){

            //Create promise
            var defer = $q.defer();

            //Resolve with elements
            defer.resolve(trackings);

            //Returns promise
            return defer.promise;
        }

        //Reset current condition
        function reset(){

            //Clear values
            trackings=[];
        }

        //Calculate max duration
        function maxDuration(){

            //Extract max duration
            return jslinq(trackings)
                .max(function (e) {
                    return e.duration;
                });
        }

        //Calculate min duration
        function minDuration(){

            //Extract min duration
            return jslinq(trackings)
                .min(function (e) {
                    return e.duration;
                });
        }

        //Total iterations
        function totalIterations(){

            //Extract count
            return jslinq(trackings)
                .count();
        }

        //Total errors
        function totalErrors(){

            //Extract count of errors
            return jslinq(trackings)
                .where(function(e){
                    return !e.isSuccess;
                })
                .count();
        }

        //Total warmups
        function totalWarmups(){

            //Extract count of errors
            return jslinq(trackings)
                .where(function(e){
                    return e.isWarmup;
                })
                .count();
        }

        //Calculate total duration
        function totalDuration(){

            //Extract sum duration
            return jslinq(trackings)
                .sum(function (e) {
                    return e.duration;
                });
        }

        //Calculate average duration
        function averageDuration(){

            //If there are no element, exit
            if (trackings.length == 0)
                return 0;

            //Extract average duration
            var avg = jslinq(trackings)
                .average(function (e) {
                    return e.duration;
                });

            //Round and return
            return Math.round(avg);
        }

        //Calculate best average duration
        function bestAverageDuration(){

            //If there are no element, exit
            if (trackings.length == 0)
                return 0;

            //Calculate 90% of source values => "X"
            var elementsToTake = Math.round((trackings.length * 90) / 100);

            //Just take the first "X" elements with minimal duration
            var orderedDurations = jslinq(trackings)
                .select(function(e){
                    return e.duration;
                })
                .orderBy(function(e){
                    return e;
                })
                .take(elementsToTake)
                .toList();

            //Sum every element on result array
            var sum = jslinq(orderedDurations)
                .sum(function(e){
                    return e;
                });

            //Calculate average and round
            var average = Math.round(sum / elementsToTake);

            //Returns value
            return average;
        }

        //Returns service schema
        return {
            all: all,
            push: push,
            fetch: fetch,
            count: count,
            reset: reset,
            maxDuration: maxDuration,
            minDuration: minDuration,
            averageDuration: averageDuration,
            bestAverageDuration: bestAverageDuration,
            totalDuration: totalDuration,
            totalIterations: totalIterations,
            totalErrors: totalErrors,
            totalWarmups: totalWarmups
        };
    }]);
}());