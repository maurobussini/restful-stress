(function () {
    angular
    .module('RestfulStress')
    .factory('timeMarkerInterceptor',
    ['$log',
    function ($log) {

        //Invoked before send request to server
        function request(config) {

            //Create timestamp with current date
            var timestamp = {
                start: new Date(),
                end: null,
                duration: null
            };

            //Set timestamp on config
            config.timestamp = timestamp;

            //Returns config
            return config;
        }

        //Invoked after received response from server
        function response(response) {

            //Retrieve configuration
            var timestamp = response.config.timestamp;

            //Set end date
            timestamp.end = new Date();
            timestamp.duration = timestamp.end - timestamp.start;

            //Returns response
            return response;
        }

        //Returns service schema
        return {
            request: request,
            response: response
        };

    }]);
}());