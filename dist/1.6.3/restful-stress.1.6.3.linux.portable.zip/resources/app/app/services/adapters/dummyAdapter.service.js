(function () {
    angular
    .module('RestfulStress')
    .factory('dummyAdapterService',
    ['$q',
    function ($q) {

        //Local variables
        var configuration = null;

        //Get current configuration
        function config(){

            //Returns configuration
            return configuration;
        }

        //Executes initialization of adapter
        function init(config){

            //Arguments validation
            if (!config) throw new Error("Argument 'config' is invalid");

            //Set values on local variables
            configuration = config;
        }

        //Execute adapter and returns promise
        function execute(){

            //Create promise
            var defer = $q.defer();

            //Dummy resolve
            setTimeout(function(){

                var dummy = {
                    status: "fake",
                    data: 'dummy execution'
                };

                //Do resolve
                defer.resolve(dummy);

            }, 1000);

            //Returns promise
            return defer.promise;
        }

        //Returns service schema
        return {
            init: init,
            config: config,
            execute: execute
        };

    }]);
}());