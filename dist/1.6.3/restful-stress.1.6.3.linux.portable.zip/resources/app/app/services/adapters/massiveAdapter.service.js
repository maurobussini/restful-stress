(function () {
    angular
    .module('RestfulStress')
    .factory('massiveAdapterService',
    ['$q', "parseService", "httpRequestService",
    function ($q, parseService, httpRequestService) {

        //Local variables
        var listeners = [];
        var timeout = 30000;
        var settings = {
            batch: JSON.stringify([
                { verb: "GET", url:'https://maps.googleapis.com/maps/api/geocode/json?address=Meran', body: null, headers: null, withCredentials: false },
                { verb: "GET", url:'https://maps.googleapis.com/maps/api/geocode/json?address=Varese', body: null, headers: null, withCredentials: false },
                { verb: "GET", url:'https://maps.googleapis.com/maps/api/geocode/json?address=Chennai', body: null, headers: null, withCredentials: false }
            ], null, "   ")
        };

        //Execute adapter and returns promise
        function execute(){

            //Create promise
            var defer = $q.defer();

            //Try parse JSON on "config.batch"
            if (!parseService.isJson(settings.batch)){

                //Compose fail result
                var invalidJsonResult = {
                    request: null,
                    isSuccess: false,
                    status: 0,
                    data: "Provided script is not a valid JSON array"
                };

                //Resolve promise
                defer.resolve(invalidJsonResult);
            }

            //Do parsing of element
            var batchArray = JSON.parse(settings.batch);

            //Define array of http promises
            var httpPromises = [];

            //Iterate all over each element on array
            for (var i = 0; i < batchArray.length; i++){

                //Compose current request
                var url = batchArray[i].url || '';
                var verb = batchArray[i].verb || 'GET';
                var headers = batchArray[i].headers || {};
                var body = batchArray[i].body || null;
                var withCredentials = batchArray[i].withCredentials || false;

                //Execute remote invoke
                var currentHttpPromise = httpRequestService
                    .invoke(url, verb, body, headers, withCredentials, timeout);

                //Push promise on array
                httpPromises.push(currentHttpPromise);
            }

            //Wait for all promises to be resolved
            $q.all(httpPromises)
                .then(function(allResults) {

                    //Define merged result
                    var mergedResult = {
                        request: null,
                        isSuccess: true,
                        status: 200,
                        data: {
                            errors:[],
                            requests: []
                        }
                    };

                    //For each available result
                    for (var k = 0; k < allResults.length; k++){

                        //Get data, isSuccess and status from current element
                        var currentStatus = allResults[k].status;
                        var currentIsSuccess = allResults[k].isSuccess;
                        var currentData = allResults[k];

                        //Update success
                        mergedResult.isSuccess = mergedResult.isSuccess && currentIsSuccess ? true : false;

                        //If merged is 200
                        if (mergedResult.status == 200){

                            //Override if current is not 200
                            mergedResult.status = currentStatus == 200
                                ? 200 : currentStatus;
                        }
                        else{

                            //If current is 200, skip, otherwise override
                            if (currentStatus != 200){
                                mergedResult.status = currentStatus;
                            }
                        }

                        //if it's failed, compose error
                        if (!currentIsSuccess){

                            //Compose structure and push
                            mergedResult.data.errors.push({
                                status: currentStatus,
                                message: currentData.data
                            });
                        }

                        //Insert result on array in "data.request"
                        mergedResult.data.requests.push(allResults[k]);
                    }

                    //Do resolve adapter promise
                    defer.resolve(mergedResult);
                });

            //Returns promise
            return defer.promise;
        }

        //Add a listener on invoke-completed
        function addListener(listener){

            //Add listener
            listeners.push(listener);
        }

        /**
         * Set settings on current instance
         */
        function setSettings(options){

            //Set values
            settings = options;

            //Invoke each listener registered
            for(var i = 0; i < listeners.length; i++)
                listeners[i]();
        }

        //Returns service schema
        return {
            name: 'massiveAdapter',
            addListener: addListener,
            execute: execute,
            getSettings: function (){
                return settings;
            },
            setSettings: setSettings,
            setTimeout: function(t){
                timeout = t;
            }
        };

    }]);
}());