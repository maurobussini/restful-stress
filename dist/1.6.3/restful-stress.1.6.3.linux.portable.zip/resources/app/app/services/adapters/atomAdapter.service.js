(function () {
    angular
    .module('RestfulStress')
    .factory('atomAdapterService',
    ['$q', 'parseService', 'httpRequestService',
    function ($q, parseService, httpRequestService) {

        //Local variables
        var listeners = [];
        var timeout = 30000;
        var verbs = ['GET', 'POST', 'OPTIONS', 'PUT', 'DELETE'];
        var bodyKinds = ['json', 'form-data', 'x-www-form-urlencoded'];

        //Default setting of module
        var settings = {
            url: 'https://maps.googleapis.com/maps/api/geocode/json?address=Meran',
            verb: verbs[0],
            body: null,
            headers: JSON.stringify({
                'Accept': "application/json",
                'Content-Type': "application/json; charset=utf-8"
            }, null, '   '),
            bodyKind: bodyKinds[0],
            withCredentials: false
        };

        //Execute adapter and returns promise
        function execute(){

            //Create promise
            var defer = $q.defer();

            //Check if options are good
            var headersOk = parseService.isJson(settings.headers || null);
            var bodyOk = parseService.isJson(settings.body || null);

            //If body or headers are not good, exit with fail
            if (!headersOk || !bodyOk){

                //Define fail result
                var failResult = {
                    request: null,
                    data: 'Headers or body are not valid JSON strings',
                    status: 0,
                    isSuccess: false
                };

                //Resolve fail
                defer.resolve(failResult);

            } else {

                //Execute remote invoke
                httpRequestService.invoke(
                    settings.url,
                    settings.verb,
                    settings.body,
                    settings.headers,
                    settings.withCredentials,
                    timeout).then(
                    function(result){
                        defer.resolve(result);
                    },
                    function(result){
                        defer.resolve(result);
                    });
            }

            //Returns promise
            return defer.promise;
        }

        //Add a listener on invoke-completed
        function addListener(listener){

            //Add listener
            listeners.push(listener);
        }

        /**
         * Set settings on current instance
         */
        function setSettings(options){

            //Set values
            settings = options;

            //Invoke each listener registered
            for(var i = 0; i < listeners.length; i++)
                listeners[i]();
        }

        //Returns service schema
        return {
            name: 'atomAdapter',
            addListener: addListener,
            execute: execute,
            verbs: verbs,
            bodyKinds: bodyKinds,
            getSettings: function (){
                return settings;
            },
            setSettings: setSettings,
            setTimeout: function(t){
                timeout = t;
            }
        };

    }]);
}());