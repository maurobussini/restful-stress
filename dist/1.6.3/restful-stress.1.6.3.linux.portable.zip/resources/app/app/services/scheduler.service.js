(function () {
    angular
    .module('RestfulStress')
    .factory('schedulerService',
    ['$log', 'engineService', '$timeout',
    function ($log, engineService, $timeout) {

        //List of time listeners
        var timeListeners = [];
        var startTime = null;

        //Add a listener on timer
        function addTimeListener(listener){

            //Check arguments
            if (!listener)
                throw new Error("Argument 'listener' is invalid");

            //Check if it is function
            if (typeof listener !== 'function')
                throw new Error("Provided listener is not a function");

            //Queue listener on array
            timeListeners.push(listener);
        }

        //Initialize
        function init(){

            //Timeout every 1 second
            $timeout(function(){

                //Log elapsed
                $log.debug("Scheduler service - time elapsed");

                //Calculate current time
                var currentTime = new Date();

                //Raise listeners
                for (var i = 0; i < timeListeners.length; i++){

                    //Get current listener
                    var current = timeListeners[i];

                    //Invoke listener passing current time
                    current(currentTime);
                }

                //Run scheduler
                runEngineExecution(currentTime);

                //Execute again if start time is set
                if (startTime)
                    init();

            }, 1000);
        }

        //Runs execution engine
        function runEngineExecution(executionTime){

            //Arguments validation
            if (!executionTime)
                throw new Error("Argument 'executionTime' is invalid");

            //Calculate current time
            var currentDateString = moment().format('YYYY-MM-DD');
            var startDateAndTimeString = currentDateString + " " + startTime;
            var startDateAndTime = moment(startDateAndTimeString, "YYYY-MM-DD HH:mm");

            var difference = executionTime - startDateAndTime;
            if (difference >= 0 && difference < 1000){
                toastr.success("SCHEDULE!!!!");
            }

            return;

            //If startTime is not set exit
            if (!startTime){
                $log.debug("Scheduled start time is not set.");
                return;
            }

            //If its not the current interval, skip

            if (difference > 1000){
                $log.debug("Current time - start time : " + difference);
                return;
            }

            //If adapter is not configured, skip
            if (!engineService.adapter()){
                $log.debug("Adapter is not configured on engine service");
                return;
            }

            //Run execution
            //engineService.start();
            toastr.info("TIMER STARTED")
        }

        //Enable scheduled task
        function enableScheduledTask(timeToStart){

            //Check arguments
            if (!timeToStart)
                throw new Error("Argument 'timeToStart' is invalid");

            //Set start time
            startTime = timeToStart;

            //Execute init
            init();
        }

        //Disable scheduled task
        function disableScheduledTask(){

            //Clear start time
            startTime = null;
        }

        //Get currently set start time
        function getStartTime(){
            return startTime;
        }

        //Check if scheduler is enabled
        function isEnabled(){

            //Is enabled is start time is valid
            return startTime && true;
        }

        //First initialization
        //init();

        //Returns service schema
        return {
            addTimeListener: addTimeListener,
            enableScheduledTask: enableScheduledTask,
            disableScheduledTask: disableScheduledTask,
            getStartTime : getStartTime,
            isEnabled : isEnabled
        };

    }]);
}());