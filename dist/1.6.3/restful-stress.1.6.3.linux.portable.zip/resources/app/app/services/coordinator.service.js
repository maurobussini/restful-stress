// (function () {
//     angular
//     .module('RestfulStress')
//     .factory('coordinatorService',
//     ['$log',
//     function ($log) {

//         //Register received message
//         chrome.runtime.onMessage.addListener(function (message, sender, sendResponse){

//             toastr.info("Received remote message");
//             sendResponse();
//         });

//         function send(){

//             var extensionId = "";
//             extensionId = chrome.runtime.id;
//             var message = { content: "Hello!" };

//             chrome.runtime.sendMessage(extensionId, message, null, function(res){
//                 $log.debug("Message sent");
//                 var dd = chrome.runtime.lastError;
//             });
//         }

//         //Returns service schema
//         return {
//             send: send
//         };

//     }]);
// }());

//*** COMMENTATO PERCHé NON ANCORA UTILIZZATO ***/