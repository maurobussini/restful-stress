(function () {
    angular
    .module('RestfulStress')
    .factory('forecastService',
    ['$log', '$q',
    function ($log, $q) {

        function forecast(){

        }

        //Returns service schema
        return {
            forecast: forecast
        };

    }]);
}());