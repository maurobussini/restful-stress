(function () {
    angular
    .module('RestfulStress')
    .factory('legacyService',
    ['$log', '$q',
    function ($log, $q) {

        /**
         * Try to parse config from storage from version 1.4.0
         * and converts to current format of that element
         * @param legacyElement Legacy element
         */
        function tryUpgradeStorageConfigFromVersion140(legacyElement){

            //Arguments validation
            if (!legacyElement) throw new Error("Argument 'legacyElement' is invalid");

            //Check is legacy element is 1.4.0
            if (!legacyElement.selectedMode){

                //If not legacy, just return
                return legacyElement;
            }

            //Compose current version
            var stored = {
                structureVersion: "1.5.0",
                registrationDate: legacyElement.registrationDate
                    ? moment(legacyElement.registrationDate).format()
                    : moment().format(),
                atom: {
                    url: legacyElement.url || '',
                    verb: legacyElement.verb || 'GET',
                    headers: legacyElement.headers || null,
                    body: legacyElement.body || null,
                    withCredentials: legacyElement.withCredentials || false
                },
                scenario: {
                    code: legacyElement.scenarioCode || null
                },
                massive: {
                    batch: legacyElement.massiveBatch || null
                },
                engine: {
                    name: legacyElement.name || "NoName",
                    mode: legacyElement.selectedMode || 'atomAdapter',
                    iterations: legacyElement.iterations || 10,
                    delay: legacyElement.delay || 100,
                    warmup: legacyElement.warmup || 5,
                    timeout: legacyElement.timeout || 30000
                }
            };

            //Returns structure
            return stored;
        }

        /**
         * Try to parse config downloaded from version 1.4.0
         * and converts to current format of that element
         * @param legacyElement Legacy element
         */
        function tryUpgradeDownloadedConfigFromVersion140(legacyElement){

            //Arguments validation
            if (!legacyElement) throw new Error("Argument 'legacyElement' is invalid");

            //Check is legacy element is 1.4.0
            if (!legacyElement.selectedMode){

                //If not legacy, just return
                return legacyElement;
            }

            //Compose current version
            var stored = {
                structureVersion: "1.5.0",
                registrationDate: legacyElement.registrationDate
                    ? moment(legacyElement.registrationDate).format()
                    : moment().format(),
                atom: {
                    url: legacyElement.atomConfig.url || '',
                    verb: legacyElement.atomConfig.verb || 'GET',
                    headers: legacyElement.atomConfig.headers || null,
                    body: legacyElement.atomConfig.body || null,
                    withCredentials: legacyElement.atomConfig.withCredentials || false
                },
                scenario: {
                    code: legacyElement.scenarioConfig.code || null
                },
                massive: {
                    batch: legacyElement.massiveConfig.batch || null
                },
                engine: {
                    name: legacyElement.engineConfig.name || "NoName",
                    mode: 'atomAdapter',
                    iterations: legacyElement.engineConfig.iterations || 10,
                    delay: legacyElement.engineConfig.delay || 100,
                    warmup: legacyElement.engineConfig.warmup || 5,
                    timeout: legacyElement.engineConfig.timeout || 30000
                }
            };

            //Returns structure
            return stored;
        }

        //Returns service schema
        return {
            tryUpgradeStorageConfigFromVersion140: tryUpgradeStorageConfigFromVersion140,
            tryUpgradeDownloadedConfigFromVersion140: tryUpgradeDownloadedConfigFromVersion140
        };

    }]);
}());