(function () {
    angular
    .module('RestfulStress')
    .factory('downloadService',
    ['$log', "$q",
    function ($log, $q) {    

        const { dialog } = require('electron').remote;        
        let fs = require("fs");    

        /**
         * Download as a file the provided content
         * @param content Content
         * @param filename File name
         * @param extension Extension
         * @param contentType ContentType (default: 'text/plain')
         * @returns {*} Returns promise
         */
        function download(content, filename, extension, contentType){

            //Check arguments
            if (!content) throw new Error("Argument 'content' is invalid");
            if (!filename) throw new Error("Argument 'filename' is invalid");
            if (!extension) throw new Error("Argument 'extension' is invalid");

            //Apply default value for contentType
            contentType = contentType || 'text/plain';

            //Create promise
            var defer = $q.defer();

            //Dialog options
            let options = {
                defaultPath : filename,
                filters:[
                    { name: '.' + extension + ' files', extensions: [extension]},
                ]
            };

            //Show save file dialog
            dialog.showSaveDialog(options, (filePath) => {

                //With invalid file, reject
                if (!filePath){
                    defer.reject("No selected file!");
                    return;
                }

                //Write file on disk
                fs.writeFile(filePath, content, (err) => {

                    //With error, reject
                    if (err){
                        defer.reject("Error writing file: " + err);
                        return;
                    }

                    //Otherwise, success
                    defer.resolve("Download completed");
                });
            });

            //Configure options for saveAs dialog
            // var options = {
            //     type: 'saveFile',
            //     suggestedName: filename,
            //     accepts:[{
            //         extensions: [extension]
            //     }]
            // };

            // //Request save file on disk to chrome
            // chrome.fileSystem.chooseEntry(options, function (entry) {

            //     //If error occurred (ex. user cancelled)
            //     if (chrome.runtime.lastError) {

            //         //Reject promise with error
            //         defer.reject(chrome.runtime.lastError.message);

            //     } else {

            //         //Creates writer for selected entry
            //         entry.createWriter(function(fileWriter) {

            //             //If content is NOT array, wrap
            //             if (!angular.isArray(content)){
            //                 content = [content];
            //             }

            //             //Create new blob to write
            //             var blob = new Blob(content, {type: contentType});

            //             //Handle write end
            //             fileWriter.onwriteend = function(e) {

            //                 //Truncate file at end of writer
            //                 e.currentTarget.truncate(e.currentTarget.position);

            //                 //If error on writeend
            //                 if (this.error){

            //                     //Reject promise with error
            //                     defer.reject(this.error.message);
            //                 }
            //                 else{

            //                     //Otherwise, success
            //                     defer.resolve("Download completed");
            //                 }
            //             };

            //             //Write to file writer
            //             fileWriter.write(blob);

            //         });
            //     }
            // });

            //Returns promise
            return defer.promise;
        }

        /**
         * Uploads content on platform
         * @param extension Extension of file
         * @returns {*} Returns promise
         */
        function upload(extension, readAsBinary){

            //Check arguments
            if (!extension) throw new Error("Argument 'extension' is invalid");

            //If "readAsBinary" is undefined, off
            readAsBinary = readAsBinary || false;

            //Create promise
            var defer = $q.defer();

            //Dialog options
            let options = {
                properties: ['openFile'],
                filters:[
                    { name: '.' + extension + ' files', extensions: [extension]},
                ]
            };

            //Open dialog
            dialog.showOpenDialog(options, (files) => {

                //With invalid files, reject
                if (!files){
                    defer.reject("No selected file!");
                    return;
                }

                //Read file
                fs.readFile(files[0], 'utf8', (err, data) => {

                    //On error, reject
                    if (err){
                        defer.reject(err);
                        return;
                    }

                    //Resolve with content
                    defer.resolve(data);
                });
            });

            // //Request open file on disk to chrome
            // chrome.fileSystem.chooseEntry(options, function(entry) {

            //     //If error occurred (ex. user cancelled)
            //     if (chrome.runtime.lastError) {

            //         //Reject promise with error
            //         defer.reject(chrome.runtime.lastError.message);

            //     } else {

            //         //Open local file
            //         entry.file(function(file) {

            //             //Create a new FileReader
            //             var reader = new FileReader();

            //             //Attach "onload" event
            //             reader.onload = function(e) {

            //                 //If error on "onload"
            //                 if (this.error){

            //                     //Reject promise with error
            //                     defer.reject(this.error.message);
            //                 }
            //                 else{

            //                     //Otherwise, success
            //                     defer.resolve(e.target.result);
            //                 }
            //             };

            //             //Read as text or binary
            //             if (readAsBinary){
            //                 reader.readAsBinaryString(file);
            //             }
            //             else{
            //                 reader.readAsText(file);
            //             }
            //         });
            //     }
            // });

            //Returns promise
            return defer.promise;
        }

        //Returns service schema
        return {
            download: download,
            upload: upload
        };

    }]);
}());