(function () {
    angular
    .module("RestfulStress")
    .controller("SchedulerController",
    ["navigateService", "schedulerService",
    function (navigateService, schedulerService) {

        //#region Bindable elements
        var ctrl = this;
        ctrl.isBusy = false;
        ctrl.scheduleIsEnabled = false;
        ctrl.scheduleStartTime = new Date().getHours() + ":" + new Date().getMinutes();
        ctrl.startScheduler = startScheduler;
        ctrl.stopScheduler = stopScheduler;
        ctrl.isEnabled = schedulerService.isEnabled;
        //#endregion

        //Starts scheduler
        function startScheduler(){
            toastr.info("SCHEDULER: Started!");
            schedulerService.enableScheduledTask(ctrl.scheduleStartTime);
        }

        //Stops scheduler
        function stopScheduler(){
            toastr.info("SCHEDULER: Stopped!");
            schedulerService.disableScheduledTask();
        }


    }]);
}());