(function () {
    angular
    .module("RestfulStress")
    .controller("ToolsController",
    ['$scope', 'downloadService', "parseService", "atomAdapterService",
    function ($scope, downloadService, parseService, atomAdapterService) {

        //#region Bindable elements
        var ctrl = this;
        ctrl.isBusy = false;
        ctrl.authorizationSchema = 'Basic';
        ctrl.authorizationUsername = '';
        ctrl.authorizationPassword = '';
        ctrl.authorizationContent = '';
		ctrl.customAuthorizationSchema = "";
		ctrl.customAuthorizationValue = "";
		ctrl.customAuthorizationResult = "";
        ctrl.calculateAuthorization = calculateAuthorization;
        ctrl.applyAuthorization = applyAuthorization;
		ctrl.customApplyAuthorization = customApplyAuthorization;
        ctrl.base64String = '';
        ctrl.convertsBase64ToFile = convertsBase64ToFile;
        ctrl.convertsFileToBase64 = convertsFileToBase64;
        //#endregion
		
		//Watch on custom authorization
		$scope.$watch(
			function() { 
				return ctrl.customAuthorizationSchema + 
					ctrl.customAuthorizationValue;
			}, 
			function(){
				//If schema or value are empty, set null, otherwise combine
				ctrl.customAuthorizationResult = !ctrl.customAuthorizationSchema || !ctrl.customAuthorizationValue 
					? ""
					: ctrl.customAuthorizationSchema  + " " + ctrl.customAuthorizationValue;
			}
		);
		
		/**
         * Apply custom authorization header to atom settings
         */
		function customApplyAuthorization(){
		
			//If authorization content is empty, exit
            if (!ctrl.customAuthorizationResult){
                return;
            }

            //Get current settings on atom
            var currentSettings = atomAdapterService.getSettings();

            //Get header and parse
            var headers = JSON.parse(currentSettings.headers);

            //Set "Authorization" header on structure
            headers["Authorization"] = ctrl.customAuthorizationResult;

            //Update settings and set on "atom"
            currentSettings.headers = JSON.stringify(headers, null, "   ");
            atomAdapterService.setSettings(currentSettings);
            toastr.success("Custom authorization has been applied to settings!");
		}

        /**
         * Apply authorization header to atom settings
         */
        function applyAuthorization(){

            //If authorization content is empty, exit
            if (!ctrl.authorizationContent){
                return;
            }

            //Get current settings on atom
            var currentSettings = atomAdapterService.getSettings();

            //Get header and parse
            var headers = JSON.parse(currentSettings.headers);

            //Set "Authorization" header on structure
            headers["Authorization"] = ctrl.authorizationContent;

            //Update settings and set on "atom"
            currentSettings.headers = JSON.stringify(headers, null, "   ");
            atomAdapterService.setSettings(currentSettings);
            toastr.success("Calculated authorization has been applied to settings!");
        }

        //Calculate authorization header value
        function calculateAuthorization(){

            //Check if username was provided
            if (!ctrl.authorizationUsername){
                toastr.warning("Please, provide a valid username");
                return;
            }

            //Check if password was provided
            if (!ctrl.authorizationPassword){
                toastr.warning("Please, provide a valid password");
                return;
            }

            //Check if schema was provided
            if (!ctrl.authorizationSchema){
                toastr.warning("Please, provide a valid schema");
                return;
            }

            //Compose combination and encode
            var combination = ctrl.authorizationUsername + ":" + ctrl.authorizationPassword;
            var encoding = btoa(combination);

            //Set value and confirm
            ctrl.authorizationContent = ctrl.authorizationSchema + " " + encoding;
            toastr.success("Authorization value calculated!");
        }

        /**
         * Converts base64 string to binary file
         */
        function convertsBase64ToFile(){

            //Check if username was provided
            if (!ctrl.base64String){
                toastr.warning("Please, provide a valid base-64 string");
                return;
            }

            try{

                //var binary = fixBinary(atob(ctrl.base64String));

                //Executes convert of data
                var binary = parseService.base64ToBinaryArray(ctrl.base64String)

                //Download file on client
                downloadService.download(binary, 'file.bin', 'bin', 'text/plain').then(
                    function(){
                        toastr.success("Binary file downloaded with success!");
                    },
                    function(err){
                        toastr.error("Error during convert/download of file: " + err);
                    });
            }
            catch(exc){
                toastr.warning("Unexpected error during conversion!");
            }
        }

        /**
         * Converts uploaded file to base-64 string
         */
        function convertsFileToBase64(){
            
            try{

                //Upload fine on application
                downloadService.upload("*", true).then(
                    function(data){

                        //Converts binary to string then set
                        //var stringData = btoa(encodeURIComponent(data));
                        //var stringData = btoa(String.fromCharCode.apply(null, new Uint8Array(data)));
                        //var stringData = b64EncodeUnicode(data);
                        //var stringData = btoa(data);
                        var stringData = btoa(data);
                        ctrl.base64String = stringData;

                        //Show confirmation
                        toastr.success("Binary file downloaded with success!");
                    },
                    function(err){
                        toastr.error("Error during convert/download of file: " + err);
                    }
                );
                
            }
            catch(exc){
                toastr.warning("Unexpected error during conversion!");
            }
        }

        function b64EncodeUnicode(str) {
            return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function(match, p1) {
                return String.fromCharCode('0x' + p1);
            }));
        }

        function fixBinary (bin) {
            var length = bin.length;
            var buf = new ArrayBuffer(length);
            var arr = new Uint8Array(buf);
            for (var i = 0; i < length; i++) {
                arr[i] = bin.charCodeAt(i);
            }
            return buf;
        }

    }]);
}());