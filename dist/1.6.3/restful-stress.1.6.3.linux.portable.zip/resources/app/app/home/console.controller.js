(function () {
    angular
    .module("RestfulStress")
    .controller("ConsoleController",
    ['$uibModalInstance', "consoleService",
    function ($uibModalInstance, consoleService) {

        //#region Bindable elements
        var ctrl = this;
        ctrl.close = close;
        ctrl.messages = "";
        //#endregion

        //Get all messages
        ctrl.messages = JSON.stringify(consoleService.fetchMessages(), null, "   ");

        //Closes current dialog
        function close(){
            $uibModalInstance.close();
        }
    }]);
}());