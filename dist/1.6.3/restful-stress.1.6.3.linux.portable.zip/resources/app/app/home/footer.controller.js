(function () {
    angular
    .module("RestfulStress")
    .controller("FooterController",
    ['$timeout', "engineService", 'schedulerService', "navigateService", "developerModeService", "$uibModal", "$scope",
    function ($timeout, engineService, schedulerService, navigateService, developerModeService, $uibModal, $scope) {

        //#region Bindable elements
        var ctrl = this;
        ctrl.totalIterations = 0;
        ctrl.currentIteration = 0;
        ctrl.scheduledStartTime = null;
        ctrl.isSchedulerEnabled = false;
        ctrl.start = start;
        ctrl.stop = stop;
        ctrl.reset = reset;
        ctrl.isBusy = false;
        ctrl.showScheduler = showScheduler;
        ctrl.showTools = showTools;
        ctrl.showConsole = showConsole;
        ctrl.isDeveloperMode = developerModeService.isEnabled;
        ctrl.showDeveloperTools = showDeveloperTools;
        //#endregion

        //Shows browser console
        function showConsole(){

            //Open modal dialog
            $uibModal.open({
                templateUrl: 'app/home/console.html',
                controller: 'ConsoleController as consoleCtrl',
                backdrop: 'static'
            });
        }

        //Starts executions
        function start(){

            //Start execution
            engineService.start();
            console.log("STARTED");
        }

        //Stops executions
        function stop(){

            //Stop execution
            engineService.stop();
        }

        //Reset executions
        function reset(){

            //Stop execution
            engineService.reset();

            //Show confirm message
            toastr.success("Reset completed.");
        }

        //Show scheduler configuration page
        function showScheduler(){

            //Execute navigation
            navigateService.navigate("/scheduler");
        }

        //Show tools page
        function showTools(){

            //Execute navigation
            navigateService.navigate("/tools");
        }

        /**
         * Show developer tools
         * 
         */
        function showDeveloperTools(){

            //Requires and windows
            const { remote } = require("electron");
            var windows = remote.BrowserWindow.getAllWindows();

            try {

                // Look for the popup window and then...
                windows[0].openDevTools();
            }
            catch(exc){

                //Error on console
                console.log(exc);
            }
        }

        //Register listener for update counters
        engineService.addListener(function(){

            //Queue events on angular event-pump
            $timeout(function() {

                //Update values
                var engineSettings = engineService.getSettings();
                ctrl.totalIterations = engineSettings.iterations;
                ctrl.currentIteration = engineService.current();
                ctrl.isBusy = engineService.isBusy();
            });
        });

        // //Register update for developer mode
        // developerModeService.addListener(function(){

        //     //Refresh developer mode
        //     ctrl.isDeveloperMode = developerModeService.isEnabled;
        // });

    }]);
}());