(function () {
    angular
    .module("RestfulStress")
    .controller("ChartController",
    ['$scope','trackingService', "performanceService",
    function ($scope, trackingService, performanceService) {

        var Highcharts = require("highcharts");

        //#region Bindable elements
        var ctrl = this;
        ctrl.isBusy = false;
        ctrl.fetchValues = fetchValues;
        ctrl.maxDuration = 0;
        ctrl.minDuration = 0;
        ctrl.totalIterations = 0;
        ctrl.totalDuration = 0;
        ctrl.clientAverageDuration = 0;
        ctrl.clientBestAverageDuration = 0;
        ctrl.serverAverageDuration = 0;
        ctrl.serverBestAverageDuration = 0;

        var chartInstance;

        //Chart settings
        var settings = {
            "chart": {
                renderTo: 'chartElement',
                type: 'area'
            },
            "credits": {
                enabled: false
            },
            "height": 200,
            "title": {
                "text": "Performance Chart"
            },
            "subtitle": {
                "text": ""
            },
            "plotOptions": {
                "area": {
                    "pointStart": 0,
                    "marker": {
                        "enabled": false,
                        "symbol": "circle",
                        "radius": 2,
                        "states": {
                            "hover": {
                                "enabled": true
                            }
                        }
                    }
                }
            },
            "series": [
                {
                    "name": "Stress",
                    "data": ctrl.stressValues,
                    "color": '#33CC33'
                },
                {
                    "name": "Warmup",
                    "data": ctrl.warmupValues,
                    "color": '#0099CC'
                },
                {
                    "name": "Errors",
                    "data": ctrl.errorValues,
                    "color": '#FF3300'
                }
            ]
        };
        //#endregion

        //Fetch list of values
        function fetchValues(){

            //Clear previous data
            var stressValues = [];
            var warmupValues = [];
            var errorValues = [];

            //Fetch data from tracked service
            ctrl.isBusy = true;
            trackingService.fetch().then(function(data){

                //Remove busy indicator
                ctrl.isBusy = false;

                //Iterate each source element and compose models
                for(var i = 0; i < data.length; i++){

                    //If current is NOT success
                    if (!data[i].isSuccess){

                        //Update only errors
                        stressValues.push(null);
                        warmupValues.push(null);
                        errorValues.push(data[i].duration);
                    }
                    else if (data[i].isWarmup){

                        //Update warmups
                        stressValues.push(null);
                        warmupValues.push(data[i].duration);
                        errorValues.push(null);
                    }
                    else{

                        //Update stress
                        stressValues.push(data[i].duration);
                        warmupValues.push(null);
                        errorValues.push(null);
                    }
                }

                //Set current date/time
                var lastUpdate = moment().format('HH:mm:ss');

                //Update stats
                ctrl.totalIterations = trackingService.totalIterations();
                ctrl.maxDuration = trackingService.maxDuration() || 0;
                ctrl.minDuration = trackingService.minDuration() || 0;
                ctrl.averageDuration = trackingService.averageDuration();
                ctrl.totalDuration = trackingService.totalDuration();

                //Update settings
                settings.series[0].name = "Stress (" + (ctrl.totalIterations - trackingService.totalWarmups()) + ")";
                settings.series[0].data = stressValues;
                settings.series[1].name = "Warmup (" + trackingService.totalWarmups() + ")";
                settings.series[1].data = warmupValues;
                settings.series[2].name = "Errors (" + trackingService.totalErrors() + ")";
                settings.series[2].data = errorValues;
                settings.subtitle.text = "last update: " + lastUpdate;

                //Create graph
                chartInstance = new Highcharts.Chart(settings);

                //Calculate averages
                ctrl.clientAverageDuration = performanceService.clientAverageDuration(1);
                ctrl.clientBestAverageDuration = performanceService.clientBestAverageDuration(1);
                ctrl.serverAverageDuration = performanceService.serverAverageDuration(1);
                ctrl.serverBestAverageDuration = performanceService.serverBestAverageDuration(1);
            });
        }

        //Fetch values
        fetchValues();
    }]);
}());