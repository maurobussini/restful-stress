const gulp = require('gulp');
const zip = require('gulp-zip');
const run = require('gulp-run');
const clean = require('gulp-clean');

let package = require('./package.json');
 
gulp.task('clean', () => {
    return gulp.src([
        "./dist"], 
        { read: false })
        .pipe(clean());
});

gulp.task('make-win', ['clean'], () => {
    return run('npm run package-win').exec();
});

gulp.task('make-mac', ['clean'], () => {
    return run('npm run package-mac').exec();
});

gulp.task('make-linux', ['clean'], () => {
    return run('npm run package-linux').exec();
});

gulp.task('release-win', ['make-win'], () => {
    var fileName = "restful-stress." +  package.version + ".win.portable.zip";
    return gulp.src('release-builds/RESTful Stress-win32-ia32/**/*')
        .pipe(zip(fileName))
        .pipe(gulp.dest('dist'));
});

gulp.task('release-mac', ['make-mac'], () => {
    var fileName = "restful-stress." +  package.version + ".mac.portable.zip";
    return gulp.src('release-builds/RESTful Stress-darwin-x64/**/*')
        .pipe(zip(fileName))
        .pipe(gulp.dest('dist'));
});

gulp.task('release-linux', ['make-linux'], () => {
    var fileName = "restful-stress." +  package.version + ".linux.portable.zip";
    return gulp.src('release-builds/RESTful Stress-linux-x64/**/*')
        .pipe(zip(fileName))
        .pipe(gulp.dest('dist'));
});

gulp.task('copy-version', () => {    
    return gulp.src("./versions.json")
        .pipe(gulp.dest('../../public/restful-stress'));
});

gulp.task('release-win-linux', ['release-win', 'release-linux']);
gulp.task('release-copy', ['release-win-linux', 'copy-version'], () => {
    return gulp.src("./dist/*.*")
        .pipe(gulp.dest('../../public/restful-stress/dist/' + package.version));
});


gulp.task('release-all', ['release-mac', 'release-win', 'release-linux']);

