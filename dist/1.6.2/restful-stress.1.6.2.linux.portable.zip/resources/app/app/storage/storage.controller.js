(function () {
    angular
    .module("RestfulStress")
    .controller("StorageController",
    ['$scope', 'storageService', 'engineService', 'atomAdapterService', 'scenarioAdapterService',"massiveAdapterService", "$location", 'legacyService',
    function ($scope, storageService, engineService, atomAdapterService, scenarioAdapterService, massiveAdapterService, $location, legacyService) {

        //#region Bindable elements
        var ctrl = this;
        ctrl.isBusy = false;
        ctrl.items = null;
        ctrl.deleteItem = deleteItem;
        ctrl.loadItem = loadItem;
        ctrl.fetch = fetch;
        //#endregion

        //Load current settings
        function loadItem(item){

            //Arguments validation
            if (!item) throw new Error("Argument 'item' is invalid");

            //If engine service is busy, exit
            if (engineService.isBusy()){
                toastr.warning("Cannot load settings while engine is running...");
                return;
            }

            //Set busy indicator
            ctrl.isBusy = true;

            //Try to convert from legacy settings
            var processed = legacyService.tryUpgradeStorageConfigFromVersion140(item);

            //Initialize adapters
            atomAdapterService.setSettings(processed.atom);
            scenarioAdapterService.setSettings(processed.scenario);
            massiveAdapterService.setSettings(processed.massive);

            //Reinitialize engine
            engineService.setSettings(processed.engine);

            //Confirm
            toastr.success("Settings were loaded");

            //Set busy indicator
            ctrl.isBusy = false;

            //Force navigation to home
            $location.path("/home");
        }

        //Deletes specified item
        function deleteItem(item){

            //Reload elements from storage
            ctrl.isBusy = true;
            storageService.load().then(function(data){

                //Find the elements to remove (same date/time)
                var elementsToRemove = jslinq(data)
                    .where(function(e){
                        return e.registrationDate == item.registrationDate;
                    })
                    .toList();

                //If element was not found, exit
                if (!elementsToRemove)
                    return;

                //Source data
                var source = jslinq(data);

                //Remove each element
                for(var i = 0; i < elementsToRemove.length; i++){
                    source = source.remove(elementsToRemove[i]);
                }

                //List without deleted element
                var cleanList = source
                    .toList();

                storageService.save(cleanList).then(function(){

                    //Remove busy indicator
                    ctrl.isBusy = false;

                    //Show confirm message
                    toastr.success("Element was deleted.");

                    //Reload list
                    fetch();
                });
            });
        }

        //Creates model
        function createModel(data){

            //Arguments validation
            if (!data) throw new Error("Argument 'data' is invalid");

            //Generate format for date
            //var time = moment(data.registrationDate).format("YYYY-MM-DD HH:mm:ss");

            //Create model
            var model = {
                structureVersion: data.structureVersion,
                registrationDate: data.registrationDate,
                atom: data.atom,
                scenario: data.scenario,
                massive: data.massive,
                engine: data.engine,
                isDeleteRequested: false
            };

            //Returns model
            return model;
        }

        //Fetches data from service
        function fetch(){

            //Fetch data from tracked service
            ctrl.isBusy = true;
            ctrl.items = [];
            storageService.load().then(function(data){

                //Iterate over each element
                ctrl.isBusy = false;
                for(var i = 0; i < data.length; i++){
                    ctrl.items.push(createModel(data[i]));
                }
            });
        }

        //Execute fetch of data
        fetch();

    }]);
}());