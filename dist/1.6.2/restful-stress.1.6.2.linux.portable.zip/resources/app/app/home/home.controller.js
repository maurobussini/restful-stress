(function () {
    angular
    .module("RestfulStress")
    .controller("HomeController",
    ['$scope', "$log", "$location", 'engineService', 'storageService', 'atomAdapterService',
    'scenarioAdapterService', "massiveAdapterService", '$uibModal', "downloadService",
    "integrationService", "httpRequestService",
    function ($scope, $log, $location, engineService, storageService, atomAdapterService,
        scenarioAdapterService, massiveAdapterService, $uibModal, downloadService,
        integrationService, httpRequestService) {

        //#region Bindable elements
        var ctrl = this;
        ctrl.isBusy = false;
        ctrl.atomSettings = null;
        ctrl.scenarioSettings = null;
        ctrl.massiveSettings = null;
        ctrl.engineSettings = null;

        //Expose settings from adapters
        ctrl.modes = engineService.modes;
        ctrl.verbs = atomAdapterService.verbs;
        ctrl.bodyKinds = atomAdapterService.bodyKinds;

        //Methods
        ctrl.save = save;
        ctrl.download = download;
        ctrl.upload = upload;
        ctrl.exportDetails = exportDetails;
        ctrl.showScenarioHelp = showScenarioHelp;
        ctrl.showMassiveHelp = showMassiveHelp;
        ctrl.resyncAtomHeadersWithBodyKind = resyncAtomHeadersWithBodyKind;
        //#endregion

        /**
         * Executes a re-sync of atom headers using provided body kind
         */
        function resyncAtomHeadersWithBodyKind(){
            
            //Get Atom settings
            var currentSettings = atomAdapterService.getSettings();

            //Executes resync
            httpRequestService.syncHeaderWithBodyKind(currentSettings);

            //Re-apply settings
            applySettings();
        };

        //Shows scenario help
        function showScenarioHelp(){

            //Open modal dialog
            $uibModal.open({
                templateUrl: 'app/help/scenarioHelp.html',
                controller: 'ScenarioHelpController as scenarioHelpCtrl',
                backdrop: 'static'
            });
        }

        //Shows massive help
        function showMassiveHelp(){

            //Open modal dialog
            $uibModal.open({
                templateUrl: 'app/help/massiveHelp.html',
                controller: 'MassiveHelpController as massiveHelpCtrl',
                backdrop: 'static'
            });
        }

        //Save settings to storage
        function save(){

            //Create package of data
            var package = {
                structureVersion: "1.5.0",
                registrationDate: moment().format(),
                atom: atomAdapterService.getSettings(),
                scenario: scenarioAdapterService.getSettings(),
                massive: massiveAdapterService.getSettings(),
                engine: engineService.getSettings()
            };

            //Invoke append on storage
            ctrl.isBusy = true;
            storageService.append(package).then(
                function(){

                    //Show confirm message
                    ctrl.isBusy = false;
                    toastr.success("Settings were saved with success.")
                },
                function(err){

                    //Show error
                    ctrl.isBusy = false;
                    toastr.error(err);
                });
        }

        //Upload setting on UI
        function upload(){

            //Open file from local (upload on extension)
            downloadService.upload('rest').then(
                function(data){

                    //Parse content
                    integrationService.uploadSettingsJson(data).then(
                        function(){
                            //Get values from adapters and engine
                            ctrl.engineSettings = engineService.getSettings();
                            ctrl.atomSettings = atomAdapterService.getSettings();
                            ctrl.scenarioSettings = scenarioAdapterService.getSettings();
                            ctrl.massiveSettings = massiveAdapterService.getSettings();
                            toastr.success("Settings were uploaded and restored with success");
                        },
                        function(err){
                            toastr.error("Error during upload of settings: " + err);
                        }
                    );
                },
                function(err){
                    toastr.error("Error during upload of settings: " + err);
                });
        }

        //Download settings on local file system
        function download(){

            //Create package of data
            var package = {
                structureVersion: "1.5.0",
                registrationDate: moment().format(),
                atom: atomAdapterService.getSettings(),
                scenario: scenarioAdapterService.getSettings(),
                massive: massiveAdapterService.getSettings(),
                engine: engineService.getSettings()
            };

            //Compose name of file
            var fileName = !ctrl.engineSettings.name
                ? "settings.rest"
                : ctrl.engineSettings.name + ".rest";

            //Json of data
            var json = JSON.stringify(package, null, "   ");

            //Execute download of settings
            downloadService.download(json, fileName, "rest").then(
                function(){
                    toastr.success("Current settings downloaded with success");
                },
                function(err){
                    toastr.error("Error during download: " + err);
                });
        }

        /**
         * Export settings details on text file
         */
        function exportDetails(){

            //Define stucture of content
            var content = 
                "*** " + ctrl.engineSettings.name + " " + 
                "(exported " + moment().format("YYYY-MM-DD HH:mm") + ") ***" + 
                "\r\n\r\n";

            //Compose name of file
            var fileName = !ctrl.engineSettings.name
                ? "settings.txt"
                : ctrl.engineSettings.name + ".txt";

            //Select mode
            switch(ctrl.engineSettings.mode){

                /***************************************/
                case 'atomAdapter': 

                    //Get atom settings
                    var atomSettings = atomAdapterService.getSettings();

                    //Append data to content
                    content = content + 
                        "url              : " + atomSettings.url + "\r\n" + 
                        "verb             : " + atomSettings.verb + "\r\n" + 
                        "body             : " + atomSettings.body + "\r\n" + 
                        "headers          : " + atomSettings.headers + "\r\n";
                        "with credentials : " + atomSettings.withCredentials + "\r\n";
                        "body kind        : " + atomSettings.bodyKind + "\r\n";
                    break;

                /***************************************/
                case 'massiveAdapter': 

                    //Get massive settings
                    var massiveSettings = massiveAdapterService.getSettings();

                    //Append data to content
                    content = content + 
                        "batch : " + massiveSettings.batch + "\r\n";
                    break;

                /***************************************/
                case 'scenarioAdapter': 

                    //Get scenario settings
                    var scenarioSettings = scenarioAdapterService.getSettings();

                    //Append data to content
                    content = content + 
                        "code : " + scenarioSettings.code + "\r\n";
                    break;
            }


            //Execute download of settings
            downloadService.download(content, fileName, "txt").then(
                function(){
                    toastr.success("Current settings exported with success");
                },
                function(err){
                    toastr.error("Error during export: " + err);
                });
        }

        //Function to update engine settings
        function applySettings(){

            //If engine is busy, exit
            if (engineService.isBusy()){
                $log.debug("Engine is busy...");
                return;
            }

            //Initialize engine
            engineService.setSettings(ctrl.engineSettings);
            atomAdapterService.setSettings(ctrl.atomSettings);
            scenarioAdapterService.setSettings(ctrl.scenarioSettings);
            massiveAdapterService.setSettings(ctrl.massiveSettings);

            //Set headers
            //ctrl.atomSettings = atomAdapterService.getSettings();
        }

        //Get values from adapters and engine
        ctrl.engineSettings = engineService.getSettings();
        ctrl.atomSettings = atomAdapterService.getSettings();
        ctrl.scenarioSettings = scenarioAdapterService.getSettings();
        ctrl.massiveSettings = massiveAdapterService.getSettings();

        //Set watch on very options element
        $scope.$watch(function(){ return JSON.stringify(ctrl.atomSettings); }, applySettings);
        $scope.$watch(function(){ return JSON.stringify(ctrl.scenarioSettings); }, applySettings);
        $scope.$watch(function(){ return JSON.stringify(ctrl.massiveSettings); }, applySettings);
        $scope.$watch(function(){ return JSON.stringify(ctrl.engineSettings); }, applySettings);            

        //Add listener on "engine" execution
        engineService.addListener(function(){
            ctrl.isBusy = engineService.isBusy();
        });

    }]);
}());