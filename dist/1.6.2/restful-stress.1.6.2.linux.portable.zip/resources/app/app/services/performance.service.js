(function () {
    angular
    .module('RestfulStress')
    .factory('performanceService',
    ['$log', "trackingService", "neuralService",
    function ($log, trackingService, neuralService) {

        var simulations = {
            thinkTime: 5000,
            multiplier: 1,
            parallelIndicator: 20
        };

        //Calculates throughput using average duration
        function calculateThroughput(averageDuration){

            //If average is 0, return
            if (averageDuration == 0)
                return 0;

            //Calculate throughput as requests / sec
            return (1000 / averageDuration).toFixed(2);
        }

        //Get client average duration of each request
        function clientAverageDuration(requestsPerIteration){

            //Returns default value if argument is invalid
            if (!requestsPerIteration || requestsPerIteration < 1)
                return 0;

            //Get iteration average
            var avgDuration = trackingService.averageDuration();

            //Divide average on each request
            return Math.round(avgDuration / requestsPerIteration);
        }

        //Get best client average duration of each request
        function clientBestAverageDuration(requestsPerIteration){

            //Returns default value if argument is invalid
            if (!requestsPerIteration || requestsPerIteration < 1)
                return 0;

            //Get iteration average
            var avgDuration = trackingService.bestAverageDuration();

            //Divide average on each request
            return Math.round(avgDuration / requestsPerIteration);
        }

        //Get server average duration of each request
        function serverAverageDuration(requestsPerIteration){

            //Returns default value if argument is invalid
            if (!requestsPerIteration || requestsPerIteration < 1)
                return 0;

            //Get average duration
            var avgDuration = trackingService.averageDuration();

            //If no data this could be null: return 0
            if (!avgDuration)
                return 0;

            //Remove 2 ms from average (1 ms are spent in request,
            //and 1 ms on response: we just remove that)
            if (avgDuration >= 2)
                avgDuration = avgDuration - 2;

            //Divide average on each request
            return Math.round(avgDuration / requestsPerIteration);
        }

        //Get server best average duration of each request
        function serverBestAverageDuration(requestsPerIteration){

            //Returns default value if argument is invalid
            if (!requestsPerIteration || requestsPerIteration < 1)
                return 0;

            //Get average duration
            var avgDuration = trackingService.bestAverageDuration();

            //If no data this could be null: return 0
            if (!avgDuration)
                return 0;

            //Remove 2 ms from average (1 ms are spent in request,
            //and 1 ms on response: we just remove that)
            if (avgDuration >= 2)
                avgDuration = avgDuration - 2;

            //Divide average on each request
            return Math.round(avgDuration / requestsPerIteration);
        }

        //Calculates inter arrival time
        function calculateInterArrivalTime(averageDuration, thinkTime){

            //Returns default value if duration is invalid
            if (!averageDuration || averageDuration <= 0)
                return 0;

            //Returns default value if thinkTime is invalid
            if (!thinkTime || thinkTime < 0)
                return 0;

            //Returns calculation
            return averageDuration + thinkTime;
        }

        //Calculate arrival rate
        function calculateArrivalRate(interArrivalTime){

            //Returns default value if inter-arrival time is invalid
            if (!interArrivalTime || interArrivalTime <= 0)
                return 0;

            //Returns value
            return (1 / interArrivalTime).toFixed(10);
        }

        //Calculates concurrent users
        function calculateConcurrentUsers(throughput, arrivalRate){

            //Returns default value if duration is invalid
            if (!throughput || throughput <= 0)
                return 0;

            //Returns default value if thinkTime is invalid
            if (!arrivalRate || arrivalRate < 0)
                return 0;

            //Calculate
            var arrivalIndicator = arrivalRate * 1000;
            return Math.round(throughput / arrivalIndicator);
        }

        //Calculates visitors per hour
        function calculateVisitorsPerHour(concurrentUsers, sessionAverageDuration){

            //Returns default value if concurrent users is invalid
            if (!concurrentUsers || concurrentUsers <= 0)
                return 0;

            //Returns default value if average duration is invalid
            if (!sessionAverageDuration || sessionAverageDuration <= 0)
                return 0;

            //Calculate value
            return Math.round(concurrentUsers * ((60 * 60 * 1000) / sessionAverageDuration));
        }

        //Calculates visitors per minute
        function calculateVisitorsPerMinute(concurrentUsers, sessionAverageDuration){

            //Returns default value if concurrent users is invalid
            if (!concurrentUsers || concurrentUsers <= 0)
                return 0;

            //Returns default value if average duration is invalid
            if (!sessionAverageDuration || sessionAverageDuration <= 0)
                return 0;

            //Calculate value
            return Math.round(concurrentUsers * ((60 * 1000) / sessionAverageDuration));
        }

        //Estimates throughput with parallel indicator
        function estimateParallelThroughput(throughput, parallelIndicator){

            //Returns default value if throughput is invalid
            if (!throughput || throughput <= 0)
                return 0;

            //Returns default value if parallelIndicator is invalid
            if (!parallelIndicator || parallelIndicator <= 0)
                return 0;

            //This estimation is based on observation and
            //should not be considered as absolute measure
            //We need to use a multiplier to "smooth" the parallel indicator;
            //this multiplier needs to be 1 when parallel indicator is 1
            //this multiplier needs to be 6 when parallel indicator is 20 or above
            var parallelMultiplier = 0;

            //If parallel is equals, greater than 20
            if (parallelIndicator >= 20){

                //Total is x6
                parallelMultiplier = 6;
            }
            //If it's equals to 1, no neutral
            else if (parallelIndicator == 1){

                //Neutral value
                parallelMultiplier = 1;
            }
            else{

                //Define training data
                var www = [
                    {input: [0.2], output: [0.6]},
                    {input: [0.1], output: [0.4]},
                    {input: [0.05], output: [0.08]},
                    {input: [0.01], output: [0.1]}
                ];

                //Do training
                neuralService.trainBrain(www);

                //Generate indicator using neural network
                var brainInput = parallelIndicator / 100;
                var brainResult = neuralService.runBrain(brainInput);
                $log.debug("neural => input: " + brainInput + ", output: " + brainResult);
                parallelMultiplier = 10 * brainResult;
            }

            var result = throughput * parallelMultiplier;
            return result.toFixed(2);
        }

        function estimateMinSimultaneousUsersImprovement(concurrentUsers){

            //Returns default value if concurrentUsers is invalid
            if (!concurrentUsers || concurrentUsers <= 0)
                return 0;

            //Minimal improvement
            var minImprovement = 20; //Percent

            //Calculate
            return Math.round( concurrentUsers * (100 + minImprovement) / 100);
        }

        function estimateMaxSimultaneousUsersImprovement(concurrentUsers){

            //Returns default value if concurrentUsers is invalid
            if (!concurrentUsers || concurrentUsers <= 0)
                return 0;

            //Minimal improvement
            var maxImprovement = 400; //Percent

            //Calculate
            return Math.round( concurrentUsers * (100 + maxImprovement) / 100);
        }

        //Returns service schema
        return {
            simulations : simulations,
            clientAverageDuration: clientAverageDuration,
            clientBestAverageDuration: clientBestAverageDuration,
            serverAverageDuration: serverAverageDuration,
            serverBestAverageDuration: serverBestAverageDuration,
            calculateThroughput: calculateThroughput,
            calculateInterArrivalTime: calculateInterArrivalTime,
            calculateArrivalRate: calculateArrivalRate,
            calculateConcurrentUsers: calculateConcurrentUsers,
            calculateVisitorsPerHour: calculateVisitorsPerHour,
            calculateVisitorsPerMinute: calculateVisitorsPerMinute,
            estimateParallelThroughput: estimateParallelThroughput,
            estimateMinSimultaneousUsersImprovement: estimateMinSimultaneousUsersImprovement,
            estimateMaxSimultaneousUsersImprovement: estimateMaxSimultaneousUsersImprovement
        };

    }]);
}());