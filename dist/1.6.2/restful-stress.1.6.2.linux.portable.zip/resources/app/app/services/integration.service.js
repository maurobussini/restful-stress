(function () {
    angular
    .module('RestfulStress')
    .factory('integrationService',
    ['$q', 'trackingService', 'parseService', "engineService", "atomAdapterService", "scenarioAdapterService", "massiveAdapterService", "legacyService",
    function ($q, trackingService, parseService, engineService, atomAdapterService, scenarioAdapterService, massiveAdapterService, legacyService) {

        // Downloads content of history in CSV format
        function downloadHistoryCsv(){

            //Create promise
            var defer = $q.defer();

            //Writes columns headers
            var rows = [];
            rows.push([
                "iteration",
                "status",
                "start",
                "duration",
                "isSuccess",
                "isWarmup"
            ]);

            //Fetch data from tracked service
            trackingService.fetch().then(function(data){

                //Iterate all elements and create models
                for (var k = 0; k < data.length; k++){

                    //Creates single ros
                    var singleRow = [
                        data[k].iterationNumber,
                        data[k].status,
                        moment(data[k].start).format(),
                        data[k].duration,
                        data[k].isSuccess,
                        data[k].isWarmup
                    ];

                    //Append row to rows
                    rows.push(singleRow);
                }

                //Creates array to write
                var output = '';
                for(var x = 0; x < rows.length; x++){
                    var stringRow = rows[x].join(";");
                    output = output + "\n" + stringRow;
                }

                //Resolve promise
                defer.resolve(output);
            });

            //Returns promise
            return defer.promise;
        }

        //Downloads history in JSON format
        function downloadHistoryJson(){

            //Create promise
            var defer = $q.defer();

            //Fetch data from tracked service
            trackingService.fetch().then(function(data){

                //Remove all "request" (too many data causes
                //a crash in "JSON.stringify"
                for(var n = 0; n < data.length; n++){
                    if (data[n].data && data[n].data.requests){
                        delete data[n].data.requests;
                    }
                }

                //Serialize data in JSON format
                var json = JSON.stringify(data, null, "   ");

                //Resolve promise
                defer.resolve(json);
            });

            //Returns promise
            return defer.promise;
        }

        //Import json settings from external file
        function uploadHistoryJson(data) {

            //Create promise
            var defer = $q.defer();

            try {

                //If data is invalid, fail
                if (!data)
                    throw new Error("Uploaded data is invalid");

                //Check if data is JSON
                if (!parseService.isJson(data))
                    throw new Error("Uploaded data is not a valid JSON.");

                //Execute parsing of JSON
                var array = JSON.parse(data);

                //If not array, fail
                if (!angular.isArray(array))
                    throw new Error("Uploaded data is not a valid JSON array.");

                //Push every element on tracking
                for (var i = 0; i < array.length; i++){

                    //Check every required property
                    if (angular.isUndefined(array[i].iterationNumber) ||
                        angular.isUndefined(array[i].start) ||
                        angular.isUndefined(array[i].status) ||
                        angular.isUndefined(array[i].duration) ||
                        angular.isUndefined(array[i].isSuccess) ||
                        angular.isUndefined(array[i].isWarmup) ||
                        angular.isUndefined(array[i].data))
                        throw new Error("Uploaded data has invalid schema");

                    //Push element on tracking service
                    trackingService.push(array[i]);
                }

                //Resolve promise
                defer.resolve();
            }
            catch(exc){

                //Reject promise
                defer.reject(exc);
            }

            //Returns promise
            return defer.promise;
        }

        //Downloads current settings in JSON format
        function downloadSettingsJson(){

            //Create promise
            var defer = $q.defer();

            //Engine config
            var engineConfig = {
                name: engineService.name(),
                iterations: engineService.iterations(),
                delay: engineService.delay(),
                warmup: engineService.warmup(),
                timeout: engineService.timeout()
            };

            //Structure of data to download
            var objectContent = {
                engineConfig: engineConfig,
                atomConfig: atomAdapterService.config(),
                scenarioConfig: scenarioAdapterService.config(),
                massiveConfig: massiveAdapterService.config()
            };

            //Stringify content
            var json = JSON.stringify(objectContent, null, "   ");

            //Resolve promise
            defer.resolve(json);

            //Returns promise
            return defer.promise;
        }

        //Uploads settings in JSON format
        function uploadSettingsJson(json){

            //Create promise
            var defer = $q.defer();

            try {

                //If data is invalid, fail
                if (!json)
                    throw new Error("Uploaded data is invalid");

                //Check if data is JSON
                if (!parseService.isJson(json))
                    throw new Error("Uploaded data is not a valid JSON.");

                //Execute parsing of data
                var settings = JSON.parse(json);

                //Try to convert data from previous version
                var processed = legacyService.tryUpgradeDownloadedConfigFromVersion140(settings);

                //Initialize adapters
                atomAdapterService.setSettings(processed.atom);
                scenarioAdapterService.settings = processed.scenario;
                massiveAdapterService.settings = processed.massive;

                //Reinitialize engine
                engineService.setSettings(processed.engine);

                //Resolve with mode
                defer.resolve();
            }
            catch(exc){

                //Reject promise
                defer.reject(exc);
            }

            //Returns promise
            return defer.promise;
        }

        //Returns service schema
        return {
            downloadHistoryCsv: downloadHistoryCsv,
            downloadHistoryJson: downloadHistoryJson,
            uploadHistoryJson: uploadHistoryJson,
            downloadSettingsJson: downloadSettingsJson,
            uploadSettingsJson: uploadSettingsJson
        };

    }]);
}());