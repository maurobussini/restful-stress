(function () {
    angular
    .module('RestfulStress')
    .factory('engineService',
    ['$log', 'atomAdapterService','trackingService', "requestsCounterInterceptor", 'scenarioAdapterService', "massiveAdapterService",
    function ($log, atomAdapterService, trackingService, requestsCounterInterceptor, scenarioAdapterService, massiveAdapterService) {

        //Local variables
        var modes = [
            { key: "atomAdapter" , name: "Atom" },
            { key: "scenarioAdapter", name: "Scenario" },
            { key: "massiveAdapter", name: "Massive" }
        ];
        var current = 0;
        var forceStop = false;
        var isBusy = false;
        var listeners = [];
        var adapter = null;
        var settings = {
            name: 'NoName',
            iterations: 10,
            delay: 100,
            warmup: 5,
            timeout: 30000,
            mode: modes[0].key
        };

        // Initialize engine with provided data
        function setSettings(options){

            //Arguments validation
            if (!options) throw new Error("Argument 'options' is invalid");

            //Set values on settings
            settings.iterations = options.iterations || 10;
            settings.delay = options.delay || 100;
            settings.warmup = options.warmup || 5;
            settings.timeout = options.timeout || 30000;
            settings.name = options.name || null;
            settings.mode = options.mode || modes[0].key;

            //Specify custom adapter
            switch (settings.mode){
                case "atomAdapter":
                    adapter = atomAdapterService;
                    break;
                case "scenarioAdapter":
                    adapter = scenarioAdapterService;
                    break;
                case "massiveAdapter":
                    adapter = massiveAdapterService;
                    break;
                default:
                    throw new Error("Not supported mode '" + settings.mode.key + "'");
            }

            //Set timeouts
            adapter.setTimeout(settings.timeout);

            //Do reset only if current is 0
            if (current == 0){

                //Reset everything
                reset();
            }

            //Raise listeners
            raiseListeners();
        }

        //Invoke every registered listeners
        function raiseListeners(){

            //Invoke each listener registered
            for(var i = 0; i < listeners.length; i++)
                listeners[i]();
        }

        //Reset counters
        function reset(){

            //If engine is running exit
            if (isBusy){
                toastr.warning("Engine is running. Please use 'stop' function.");
                return;
            }

            //Reset current iterations
            current = 0;
            forceStop = false;

            //Reset tracking service
            trackingService.reset();

            //Reset requests counter
            requestsCounterInterceptor.reset();

            //Raise listeners
            raiseListeners();
        }

        //Force stop of execution
        function stop(){

            //If engine is non running exit
            if (!isBusy){
                toastr.warning("Engine is already stopped.");
                return;
            }

            //Set force stop flag
            forceStop = true;

            //Set busy indicator
            isBusy = false;

            //Show confirm message
            toastr.info("Stop in progress.Please, wait...");

            //Raise listeners
            raiseListeners();
        }

        //Starts execution of runner
        function start(){

            //If engine is running, exit
            if (isBusy){
                toastr.warning("Engine is already running.");
                return;
            }

            //Reset counter
            reset();

            //Set busy indicator
            isBusy = true;

            //Configure "whiletrue" runner to execute operation
            var runner = whiletrue(getContinueIterationCondition, singleStressAction, settings.delay);

            //Show message
            toastr.info("Engine execution started...");

            //Run element, than show completed message
            runner.run().then(function(){

                //Set busy indicator
                isBusy = false;

                //Raise listeners
                raiseListeners();

                //Raise completed message
                toastr.success("Requested execution was completed");
            });
        }

        //Add a listener on invoke-completed
        function addListener(listener){

            //Add listener
            listeners.push(listener);
        }

        //Get condition for continue iteration
        function getContinueIterationCondition(state){

            //Iterate while current iteration is lower that total iterations
            return state.index < settings.iterations &&
                forceStop == false;
        }

        //Execute action for stress one time the service
        function singleStressAction(done, state){

            //Function to append tracking
            var appendTracking = function(result){

                //Append iteration number
                result.iterationNumber = state.index;

                //Check if current iteration is "warmup"
                result.isWarmup = state.iterations < settings.warmup;

                //Push element on tracking
                trackingService.push(result);
            };

            //Trace current date
            var start = new Date();

            //Executes adapter
            adapter.execute()
                .then(function(data){

                    //Calculate duration
                    var endSuccess = new Date();
                    var durationSuccess = endSuccess - start;

                    //Set start on data (if missing)
                    if (!data.start)
                        data.start = start;

                    //Set duration on data (if missing)
                    if (!data.duration)
                        data.duration = durationSuccess;

                    if (state.time && state.time.duration)
                        data.duration = state.time.duration;

                    //Append data to tracking
                    appendTracking(data);
                })
                .finally(function(){

                    //Increment number of completed iterations
                    current++;

                    //Raise listeners
                    raiseListeners();

                    //Invoke of "done"
                    done();
                });
        }

        //Returns service schema
        return {
            reset: reset,
            start: start,
            stop: stop,
            addListener: addListener,
            current: function(){ return current; },
            isBusy: function(){ return isBusy; },
            getSettings: function (){
                return settings;
            },
            setSettings: setSettings,
            adapter: function(){ return adapter; },
            modes: modes
        };

    }]);
}());