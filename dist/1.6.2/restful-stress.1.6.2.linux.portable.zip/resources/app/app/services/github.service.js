(function () {
    angular
    .module('RestfulStress')
    .factory('githubService',
    ['$http', '$log', '$q', 
    function ($http, $log, $q) {

        /**
         * Get last available version
         */
        function getLastAvailableVersion() {

            //Create new defer
            var defer = $q.defer();

            //Invoke JSON on GitHub to retrieve versions
            $http.get('https://raw.githubusercontent.com/maurobussini/restful-stress/master/versions.json').then(

                //Success
                function(response) {

                    //Get list of versions
                    var firstVersion = jslinq(response.data)
                        .orderByDescending(function(el){
                            return el.version;
                        })
                        .firstOrDefault(function(){
                            return true;
                        });

                    //Resolve
                    defer.resolve(firstVersion);                    
                },

                //Error
                function (err) {

                    //With error, returns null
                    defer.resolve(null);
                }
            );  

            //Returns promise
            return defer.promise;
        }

        /**
         * Check if first version is greater then second
         * 
         * @param {any} first First version
         * @param {any} second Second version
         * @returns Returns true if greater
         */
        function isVersionGreater(first, second){

            //Arguments validation
            if (!first) throw new Error("Argument 'first' is invalid");
            if (!second) throw new Error("Argument 'second' is invalid");

            //Split first and second
            var firstSegments = first.split(".");
            var secondSegments = second.split(".");

            //Error with invalid segments, throw
            if (firstSegments.length != 3) throw new Error('First segments error');
            if (secondSegments.length != 3) throw new Error('Second segments error');

            //Convert as integer
            firstSegments[0] = parseInt(firstSegments[0]);
            firstSegments[1] = parseInt(firstSegments[1]);
            firstSegments[2] = parseInt(firstSegments[2]);
            secondSegments[0] = parseInt(secondSegments[0]);
            secondSegments[1] = parseInt(secondSegments[1]);
            secondSegments[2] = parseInt(secondSegments[2]);

            //Check if "major"" is different
            if (firstSegments[0] > secondSegments[0]) {

                //First is greater
                return true;
            }
            if (firstSegments[0] < secondSegments[0]) {

                //Second is greater
                return false
            }
            else{

                //Check minor
                if (firstSegments[1] > secondSegments[1]) {

                    //First is greater
                    return true;   
                }
                if (firstSegments[1] < secondSegments[1]) {

                    //Second is greater
                    return false
                }
                else {

                    //Check revision
                    if (firstSegments[2] > secondSegments[2]) {

                        //First is greater
                        return true;   
                    }
                    if (firstSegments[2] < secondSegments[2]) {

                        //Second is greater
                        return false
                    }
                    else
                    {
                        //Everything is equal
                        return false;
                    }
                }
            }
        }        
            
        //Returns schema of module
        return {
            getLastAvailableVersion: getLastAvailableVersion, 
            isVersionGreater: isVersionGreater
        };

    }]);
}());