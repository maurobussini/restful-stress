(function () {
    angular
    .module("RestfulStress")
    .controller("BodyController",
    ['$uibModalInstance', 'parseService', 'historyItem', "downloadService", "atomAdapterService",
    function ($uibModalInstance, parseService, historyItem, downloadService, atomAdapterService) {

        //#region Bindable elements
        var ctrl = this;
        ctrl.data = null;
        ctrl.isJson = false;
        ctrl.size = 0;
        ctrl.close = close;
        ctrl.download = download;
        ctrl.bearer = null;
        ctrl.applyBearer = applyBearer;
        //#endregion

        //Closes current dialog
        function close(){
            $uibModalInstance.close();
        }

        /**
         * Tries to extract bearer token from body
         * and apply it to settings of atomAdapter
         */
        function applyBearer(){

            if (!ctrl.bearer){
                throw new Error("Bearer token could not be found");
            }

            //Get current settings on atom
            var currentSettings = atomAdapterService.getSettings();

            //Get header and parse
            var headers = JSON.parse(currentSettings.headers);

            //Set "Authorization" header on structure
            headers["Authorization"] = "Bearer " + ctrl.bearer;

            //Update settings and set on "atom"
            currentSettings.headers = JSON.stringify(headers, null, "   ");
            atomAdapterService.setSettings(currentSettings);
            toastr.success("Bearer token has been applied to settings!");
        }

        /**
         * Get bearer token from body, if exits
         */
        function extractBearerToken(){

            //Clean bearer
            ctrl.bearer = null;

            //If history data is undefined, exit
            if (!historyItem.data){
                return;
            }

            //try to get data from object
            var accessToken = historyItem.data["access_token"];
            var tokenType = historyItem.data["token_type"];

            //If "access_token" or "token_type" are empty, exit
            if (!accessToken || !tokenType){
                return;
            }

            //Set bearer token
            ctrl.bearer = accessToken;
        }

        /**
         * Download content on local computer
         */
        function download(){

            //If data is invalid, exit
            if (angular.isUndefined(ctrl.data) || ctrl.data == null){
                toastr.warning("Content is empty and cannot be downloaded!");
                return;
            }

            //Generate file extension
            var extension = ctrl.isJson
                ? "json"
                : "data";

            //Data to write on file
            var dataToWrite = ctrl.data;

            ////If not json data, try to split by "\n"
            //if (!ctrl.isJson){
            //
            //    //Replace "\\n" with "\n"
            //    dataToWrite = ctrl.data.replace("\\n", "\n");
            //}
            //else{
            //
            //    //Parse content
            //    var parsedObj = JSON.parse(ctrl.data);
            //    dataToWrite = JSON.stringify(parsedObj, null, "   ");
            //}

            //Start download of data
            downloadService.download(dataToWrite, "content." + extension, extension).then(
                function(){
                    toastr.success("Content was correctly downloaded on local computer");
                },
                function(err){
                    toastr.error("Error during download on local computer: " + err);
                });
        }

        //Check is provided data is JSON
        //ctrl.isJson = parseService.isJson(historyItem.data);

        //Select by type
        if ((typeof historyItem.data == 'undefined') || (historyItem.data == null)){
            ctrl.data = null;
            ctrl.isJson = false;
        }
        else if (typeof historyItem.data == 'string'){
            ctrl.data = historyItem.data;
            ctrl.isJson = false;
        }
        else if (typeof historyItem.data == 'object'){
            ctrl.data = JSON.stringify(historyItem.data, null, "   ");
            ctrl.isJson = true;
        }
        else {
            ctrl.data = historyItem.data.toString();
            ctrl.isJson = false;
        }

        //Set size of element
        ctrl.size = !ctrl.data ? 0 : ctrl.data.length;

        //Try to extract bearer
        extractBearerToken();

    }]);
}());