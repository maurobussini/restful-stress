(function () {
    angular
    .module('RestfulStress')
    .factory('scenarioAdapterService',
    ['$q', "$window",
    function ($q, $window) {

        var $ = require("jquery");

        //Local variables
        var listeners = [];
        var timeout = 30000;
        var settings = {
            code: "$.ajax({\n" +
            "\turl:'https://maps.googleapis.com/maps/api/geocode/json?address=Meran',\n" +
            "\tmethod:'GET',\n" +
            "\tsuccess: function(res){\n" +
            "\t\tdone(res);\n" +
            "\t},\n" +
            "\terror: function(err){\n" +
            "\t\tdone(err);\n" +
            "}});\n"
        };

        //Execute adapter and returns promise
        function execute(){

            //Create promise
            var defer = $q.defer();

            //Compile code and launch it
            compile().then(
                function(res){
                    defer.resolve(res);
                });

            //Returns promise
            return defer.promise;
        }

        //Do compile of code on scenario without execute
        function compile(){

            //Create promise
            var defer = $q.defer();

            //Fail function
            var failFn = function(e){

                //Resolve promise (with error)
                defer.resolve({
                    isSuccess: false,
                    status: 0,
                    data: e.message
                });
            };

            //Check previous file existence
            var existsFn = function(fs){

                //Remove file if exists
                fs.root.getFile('buildScenario.scenario', { create: false },
                    function doesExists(){

                        //Delete previous
                        delFn(fs);
                    },
                    function doesNotExists(){

                        //Do initialize
                        initFn(fs);
                    }
                );
            };

            //Delete previous
            var delFn = function(fs){

                //Remove file if exists
                fs.root.getFile('buildScenario.scenario', { create: false }, function(entryToDelete){
                    entryToDelete.remove(function(){

                        //Create
                        initFn(fs);
                    });
                }, failFn);
            };

            //Init function
            var initFn = function(fs){

                //Request create of temporary file
                fs.root.getFile('buildScenario.scenario', { create: true, exclusive: false }, function(fileEntry) {

                    //A file is created with these properties
                    // fileEntry.isFile === true
                    // fileEntry.name == 'buildScenario.scenario'
                    // fileEntry.fullPath == '/buildScenario.scenario'

                    //Creare a writer to into it
                    fileEntry.createWriter(function(fileWriter) {

                        //Do fail on error
                        fileWriter.onerror = failFn;

                        //Get full name (URL) of file
                        var urlo = fileEntry.toURL();

                        //On end of write of temporary file
                        fileWriter.onwriteend = function() {

                            //Try compile (errors can exists)
                            try{

                                //Dynamically load a script using the file (local) URL
                                $.getScript(urlo, function(data, textStatus, jqxhr)
                                {
                                    //Script is now loaded and executed.

                                    //Try execution that can throw unhandled exception
                                    try{

                                        //Set a timeout for long executions; maybe the
                                        //user code do not invoke "done": in that case
                                        //the environment will fail in 10 seconds

                                        //Run setTimeout
                                        setTimeout(function(){

                                            //Resolve with timeout
                                            defer.resolve({
                                                isSuccess: false,
                                                status: 0,
                                                data: "timeout error: your script " +
                                                    "took more than " + (timeout / 1000) + " seconds"
                                            });

                                        }, timeout);

                                        //Execute compiled scenario
                                        window.compiledScenario(function(doneResult){

                                            //Generate result and resolve promise
                                            var processedResult = generateResult(doneResult);
                                            defer.resolve(processedResult);
                                        });
                                    }
                                    catch(unhandledException){

                                        //Resolve compile exception
                                        defer.resolve({
                                            isSuccess: false,
                                            status: 0,
                                            data: "unhandled exception:" + unhandledException.message
                                        });
                                    }
                                });
                            }
                            catch(compileException){

                                //Resolve compile exception
                                defer.resolve({
                                    isSuccess: false,
                                    status: 0,
                                    data: "compile exception:" + compileException.message
                                });
                            }
                        };

                        //Define all JavaScript code to compile
                        var fullJsCode = "window.compiledScenario = " +
                            "function(done){\n" + 
                            "var $ = require('jquery');\n" + 
                            settings.code + "\n" + 
                            "};";

                        //Create a new Blob and write scenario code to it
                        var blob = new Blob([fullJsCode], {type: 'text/plain'});
                        fileWriter.write(blob);

                    }, failFn);

                }, failFn);

            };

            //Request HTML5 fileSystem API and access to fs on temporary area
            window.requestFileSystem  = window.requestFileSystem || window.webkitRequestFileSystem;
            window.requestFileSystem(window.TEMPORARY, 5*1024*1024, existsFn, failFn);

            //Returns promise
            return defer.promise;
        }

        //Generates a result using a raw data
        function generateResult(raw){

            //If raw element is null or invalid
            if (!raw){

                //Returns fail with empty
                return {
                    isSuccess: false,
                    status: 0,
                    data: null
                };
            }

            //If raw is string or number
            if (typeof raw === 'string' || typeof raw === 'number'){

                //Returns success with empty
                return {
                    isSuccess: true,
                    status: 200,
                    data: raw
                };
            }

            //If raw is object and has 'status' and 'statustext'
            if (typeof raw === 'object' &&
                typeof raw.status !== 'undefined' &&
                typeof raw.statusText !== 'undefined'){

                //Returns success with empty
                return {
                    isSuccess: false,
                    status: raw.status,
                    data: raw.statusText
                };
            }

            //If raw is object or array
            if (typeof raw === 'object' || typeof raw === 'array'){

                //Stringify element
                var content = JSON.stringify(raw, null, "   ");

                //Build structure and return
                return {
                    isSuccess: true,
                    status: 200,
                    data: content
                };
            }

            //Otherwise fail with generic
            return {
                isSuccess: true,
                status: 200,
                data: (typeof raw).toString()
            };
        }

        //Add a listener on invoke-completed
        function addListener(listener){

            //Add listener
            listeners.push(listener);
        }

        /**
         * Set settings on current instance
         */
        function setSettings(options){

            //Set values
            settings = options;

            //Invoke each listener registered
            for(var i = 0; i < listeners.length; i++)
                listeners[i]();
        }

        //Returns service schema
        return {
            name: 'scenarioAdapter',
            addListener: addListener,
            execute: execute,
            compile: compile,
            getSettings: function (){
                return settings;
            },
            setSettings: setSettings,
            setTimeout: function(t){
                timeout = t;
            }
        };

    }]);
}());