(function () {
    angular
    .module('RestfulStress')
    .factory('requestsCounterInterceptor',
    ['$log',
    function ($log) {

        //Number of requests and responses
        var requests = 0;
        var responses = 0;

        //Invoked before send request to server
        function request(config) {

            //Increment only if "isHandledXhrRequest" is
            //available (the one set on "httpRequestService"
            if (config.isHandledXhrRequest){

                //Increment requests
                requests = requests + 1;
            }

            //Returns config
            return config;
        }

        //Invoked after received response from server
        function response(response) {

            //Increment only if "isHandledXhrRequest" is
            //available (the one set on "httpRequestService"
            if (response.config.isHandledXhrRequest){

                //Increment responses
                responses = responses + 1;

                //Remove property "isHandledXhrRequest" (no more useful)
                delete response.config.isHandledXhrRequest;
            }

            //Returns response
            return response;
        }

        //Get total requests
        function totalRequests(){
            return requests;
        }

        //Get total responses
        function totalResponses(){
            return responses;
        }

        //Reset counters
        function reset(){
            requests = 0;
            responses = 0;
        }

        //Returns service schema
        return {
            request: request,
            response: response,
            totalRequests: totalRequests,
            totalResponses: totalResponses,
            reset: reset
        };

    }]);
}());