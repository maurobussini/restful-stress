(function () {
    angular
    .module("RestfulStress")
    .controller("PerformanceHelpController",
    ['$uibModalInstance',
    function ($uibModalInstance) {

        //#region Bindable elements
        var ctrl = this;
        ctrl.close = close;
        //#endregion

        //Closes current dialog
        function close(){
            $uibModalInstance.close();
        }
    }]);
}());