(function () {
    angular
    .module("RestfulStress")
    .controller("MassiveHelpController",
    ['$uibModalInstance',
    function ($uibModalInstance) {

        //#region Bindable elements
        var ctrl = this;
        ctrl.close = close;
        ctrl.data = JSON.stringify([
            { verb: "GET", url:'https://maps.googleapis.com/maps/api/geocode/json?address=Meran', body: null, headers: null, withCredentials: false },
            { verb: "POST", url:'http://www.somedomain.org/api/update', body: { id: 23, name: 'John' } , headers: { 'Accept': "application/json" }, withCredentials: false },
            { verb: "GET", url:'https://maps.googleapis.com/maps/api/geocode/json?address=Chennai', withCredentials: true }
        ], null, "   ");
        //#endregion

        //Closes current dialog
        function close(){
            $uibModalInstance.close();
        }
    }]);
}());