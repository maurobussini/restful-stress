const gulp = require('gulp');
const zip = require('gulp-zip');
const run = require('gulp-run');
let package = require('./package.json');
 
gulp.task('default', () => {
    //File name
    var fileName = "restful-stress." +  package.version + ".win.portable.zip";

    gulp.src('release-builds/RESTful Stress-win32-ia32/**/*')
        .pipe(zip(fileName))
        .pipe(gulp.dest('dist'));
});

gulp.task('make-win', () => {
    return run('npm run package-win').exec();
});

gulp.task('make-mac', () => {
    return run('npm run package-mac').exec();
});

gulp.task('make-linux', () => {
    return run('npm run package-linux').exec();
});

gulp.task('release-win', ['make-win'], () => {
    var fileName = "restful-stress." +  package.version + ".win.portable.zip";
    return gulp.src('release-builds/RESTful Stress-win32-ia32/**/*')
        .pipe(zip(fileName))
        .pipe(gulp.dest('dist'));
});

gulp.task('release-mac', ['make-mac'], () => {
    var fileName = "restful-stress." +  package.version + ".mac.portable.zip";
    return gulp.src('release-builds/RESTful Stress-darwin-x64/**/*')
        .pipe(zip(fileName))
        .pipe(gulp.dest('dist'));
});

gulp.task('release-linux', ['make-linux'], () => {
    var fileName = "restful-stress." +  package.version + ".linux.portable.zip";
    return gulp.src('release-builds/RESTful Stress-linux-x64/**/*')
        .pipe(zip(fileName))
        .pipe(gulp.dest('dist'));
});

gulp.task('release-win-linux', ['release-win', 'release-linux']);
gulp.task('release-all', ['release-mac', 'release-win', 'release-linux']);

